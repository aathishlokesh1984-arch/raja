import React from 'react';
import { 
  Plus, 
  Grid, 
  LayoutGrid, 
  Columns, 
  Sparkles, 
  Layers, 
  Volume2,
  Trash2,
  Undo2
} from 'lucide-react';
import { ComicBook, ComicPanel } from '../types/comic';
import { ComicPanelItem } from './ComicPanelItem';
import { playComicSFX } from '../utils/soundEffectsAudio';

interface ComicCanvasProps {
  comic: ComicBook;
  onUpdateComic: (updated: ComicBook) => void;
  onGenerateSvgArt: (panelId: string) => Promise<void>;
  onGenerateImageArt: (panelId: string) => Promise<void>;
  generatingPanelId: string | null;
}

export const ComicCanvas: React.FC<ComicCanvasProps> = ({
  comic,
  onUpdateComic,
  onGenerateSvgArt,
  onGenerateImageArt,
  generatingPanelId,
}) => {
  // Update a single panel
  const handleUpdatePanel = (updatedPanel: ComicPanel) => {
    const updatedPanels = comic.panels.map((p) =>
      p.id === updatedPanel.id ? updatedPanel : p
    );
    onUpdateComic({
      ...comic,
      panels: updatedPanels,
    });
  };

  // Delete a panel
  const handleDeletePanel = (panelId: string) => {
    if (comic.panels.length <= 1) {
      alert('A comic story must contain at least 1 panel!');
      return;
    }
    const filtered = comic.panels
      .filter((p) => p.id !== panelId)
      .map((p, idx) => ({ ...p, panelNumber: idx + 1 }));
    onUpdateComic({
      ...comic,
      panels: filtered,
    });
    playComicSFX('CLICK');
  };

  // Add new panel
  const handleAddPanel = () => {
    const newPanelNumber = comic.panels.length + 1;
    const newPanel: ComicPanel = {
      id: `panel-${Date.now()}`,
      panelNumber: newPanelNumber,
      cameraShot: 'medium_action',
      sceneDescription: 'The characters prepare for the next encounter...',
      visualPrompt: `Dynamic comic panel in ${comic.genre} style, showing character action, detailed background with ink hatching and dramatic lighting`,
      caption: 'Meanwhile, across the sector...',
      captionTheme: 'classic_yellow',
      captionPosition: 'top-left',
      speechBubbles: [
        {
          id: `sb-${Date.now()}`,
          speaker: comic.characters[0]?.name || 'Hero',
          text: 'We are running out of time!',
          type: 'speech',
          x: 40,
          y: 35,
          tailDirection: 'bottom-left',
        },
      ],
      soundEffects: [
        {
          id: `sfx-${Date.now()}`,
          text: 'POW!',
          x: 65,
          y: 55,
          rotation: 10,
          style: 'burst_yellow',
          size: 'lg',
        },
      ],
    };

    onUpdateComic({
      ...comic,
      panels: [...comic.panels, newPanel],
    });
    playComicSFX('POW');
  };

  // Switch layout
  const currentLayout = comic.pageLayout || 'grid_4';
  const handleLayoutChange = (layout: 'grid_4' | 'classic_6' | 'strip_3' | 'webtoon_vertical') => {
    onUpdateComic({
      ...comic,
      pageLayout: layout,
    });
    playComicSFX('CLICK');
  };

  // Quick sound FX sticker board
  const quickSoundEffects = ['POW!', 'BAM!', 'KRAK-THOOM!', 'ZAP!', 'WHOOSH!', 'BZZZT!', 'WHAM!'];

  return (
    <div className="w-full max-w-7xl mx-auto px-4 py-6">
      {/* Comic Page Header Banner */}
      <div className="bg-white border-4 border-black comic-shadow-lg p-4 mb-6">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b-2 border-black pb-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="bg-red-600 text-white font-mono text-[10px] font-bold px-2 py-0.5 uppercase tracking-widest">
                {comic.genre}
              </span>
              <span className="text-zinc-500 font-mono text-xs">
                {comic.artStyle}
              </span>
            </div>
            <h1 className="font-comic-title text-3xl sm:text-4xl text-black tracking-wide leading-none mt-1">
              {comic.title}
            </h1>
            <p className="font-comic-body font-bold text-amber-700 text-sm mt-0.5">
              {comic.issue}
            </p>
          </div>

          {/* Page Layout Controls */}
          <div className="flex items-center gap-3">
            <div className="flex items-center bg-zinc-100 p-1 border-2 border-black rounded-xs">
              <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-600 mr-2 px-1">
                Layout:
              </span>
              <button
                onClick={() => handleLayoutChange('grid_4')}
                className={`p-1.5 rounded-xs transition-colors cursor-pointer ${
                  currentLayout === 'grid_4' ? 'bg-amber-300 border border-black' : 'hover:bg-zinc-200'
                }`}
                title="2x2 Grid (4 Panels)"
              >
                <Grid className="w-4 h-4 text-black" />
              </button>
              <button
                onClick={() => handleLayoutChange('classic_6')}
                className={`p-1.5 rounded-xs transition-colors cursor-pointer ${
                  currentLayout === 'classic_6' ? 'bg-amber-300 border border-black' : 'hover:bg-zinc-200'
                }`}
                title="Classic 6-Panel Layout"
              >
                <LayoutGrid className="w-4 h-4 text-black" />
              </button>
              <button
                onClick={() => handleLayoutChange('strip_3')}
                className={`p-1.5 rounded-xs transition-colors cursor-pointer ${
                  currentLayout === 'strip_3' ? 'bg-amber-300 border border-black' : 'hover:bg-zinc-200'
                }`}
                title="Cinematic 3-Panel Strip"
              >
                <Columns className="w-4 h-4 text-black" />
              </button>
            </div>

            <button
              onClick={handleAddPanel}
              className="flex items-center gap-1.5 bg-yellow-400 hover:bg-yellow-300 text-black font-comic-title text-sm px-3 py-1.5 border-2 border-black comic-shadow-sm transition-transform active:translate-y-0.5 cursor-pointer uppercase"
            >
              <Plus className="w-4 h-4" />
              Add Panel
            </button>
          </div>
        </div>

        {/* Synopsis & Characters Row */}
        <div className="pt-3 flex flex-wrap items-center justify-between gap-4 text-xs font-mono">
          <div className="max-w-2xl text-zinc-700 italic">
            "{comic.synopsis}"
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-bold text-black uppercase tracking-wider text-[11px]">Roster:</span>
            {comic.characters.map((ch) => (
              <span
                key={ch.id}
                className="bg-amber-100 border border-black px-2 py-0.5 rounded-xs text-[11px] font-bold text-zinc-800"
                style={{ borderLeftColor: ch.signatureColor, borderLeftWidth: 4 }}
                title={`${ch.role}: ${ch.visualDescription}`}
              >
                {ch.name}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Comic Page Surface (Authentic Comic Book Page with Gutters) */}
      <div className="comic-paper-texture border-4 border-black comic-shadow-xl p-4 sm:p-6 mb-8 relative">
        {/* Subtle Page Corner Fold Aesthetic */}
        <div className="absolute top-0 right-0 w-8 h-8 bg-amber-200 border-b-2 border-l-2 border-black rotate-0" />

        {/* Interactive Soundboard Bar */}
        <div className="mb-4 bg-zinc-900 text-white p-2 border-2 border-black flex items-center justify-between flex-wrap gap-2 text-xs">
          <div className="flex items-center gap-2">
            <Volume2 className="w-4 h-4 text-amber-400 animate-pulse" />
            <span className="font-comic-title text-amber-400 text-sm tracking-wider uppercase">
              SFX Soundboard:
            </span>
            <span className="text-zinc-400 text-[11px] hidden sm:inline">
              Click to audition retro synth sound effects
            </span>
          </div>

          <div className="flex items-center gap-1.5 flex-wrap">
            {quickSoundEffects.map((sfx) => (
              <button
                key={sfx}
                onClick={() => playComicSFX(sfx)}
                className="bg-yellow-400 hover:bg-yellow-300 text-red-600 font-comic-title text-xs px-2 py-0.5 border border-black comic-shadow-sm transition-transform active:scale-95 cursor-pointer"
              >
                {sfx}
              </button>
            ))}
          </div>
        </div>

        {/* Panel Grid Based on Layout */}
        <div
          className={`grid gap-4 sm:gap-6 ${
            currentLayout === 'classic_6'
              ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3'
              : currentLayout === 'strip_3'
              ? 'grid-cols-1 md:grid-cols-3'
              : currentLayout === 'webtoon_vertical'
              ? 'grid-cols-1 max-w-xl mx-auto'
              : 'grid-cols-1 md:grid-cols-2' // grid_4 default
          }`}
        >
          {comic.panels.map((panel) => (
            <ComicPanelItem
              key={panel.id}
              panel={panel}
              genre={comic.genre}
              artStyle={comic.artStyle}
              onUpdatePanel={handleUpdatePanel}
              onDeletePanel={() => handleDeletePanel(panel.id)}
              onGenerateSvgArt={onGenerateSvgArt}
              onGenerateImageArt={onGenerateImageArt}
              isGeneratingArt={generatingPanelId === panel.id}
            />
          ))}
        </div>

        {/* Page Footer - Classic Comic Stamp */}
        <div className="mt-8 pt-4 border-t-2 border-black flex items-center justify-between flex-wrap gap-3">
          <div className="text-[11px] font-mono text-zinc-600">
            PAGE 1 · {comic.title} · {comic.issue} · CRAFTED WITH GEMINI
          </div>

          {/* Classic "TO BE CONTINUED..." Box */}
          <div className="bg-yellow-400 border-2 border-black px-3 py-1 font-comic-title text-sm tracking-wider text-black comic-shadow-sm rotate-1">
            TO BE CONTINUED...
          </div>
        </div>
      </div>
    </div>
  );
};
