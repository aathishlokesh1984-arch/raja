import React, { useState } from 'react';
import { 
  FileText, 
  Copy, 
  Download, 
  Check, 
  Sparkles, 
  Edit3,
  BookOpen
} from 'lucide-react';
import { ComicBook } from '../types/comic';
import { playComicSFX } from '../utils/soundEffectsAudio';

interface ComicScriptViewerProps {
  comic: ComicBook;
  onOpenCanvas: () => void;
}

export const ComicScriptViewer: React.FC<ComicScriptViewerProps> = ({
  comic,
  onOpenCanvas,
}) => {
  const [copied, setCopied] = useState(false);

  // Generate plain-text standard comic script
  const generateScriptText = () => {
    let script = `========================================================
${comic.title.toUpperCase()}
${comic.issue.toUpperCase()}
GENRE: ${comic.genre} | ART STYLE: ${comic.artStyle}
LOGLINE: ${comic.synopsis}
========================================================

CAST OF CHARACTERS:
`;

    comic.characters.forEach((char) => {
      script += `- ${char.name.toUpperCase()} (${char.role}): ${char.visualDescription}\n`;
    });

    script += `\n========================================================\nPAGE ONE\n========================================================\n\n`;

    comic.panels.forEach((p) => {
      script += `PANEL ${p.panelNumber}\n`;
      script += `CAMERA: [${p.cameraShot.toUpperCase().replace('_', ' ')}]\n`;
      script += `SCENE: ${p.sceneDescription}\n`;
      script += `ART NOTE: ${p.visualPrompt}\n\n`;

      if (p.caption) {
        script += `CAPTION: "${p.caption}"\n\n`;
      }

      p.speechBubbles.forEach((sb) => {
        const typeNote = sb.type !== 'speech' ? ` (${sb.type.toUpperCase()})` : '';
        script += `${sb.speaker.toUpperCase()}${typeNote}: "${sb.text}"\n`;
      });

      if (p.soundEffects.length > 0) {
        script += `\nSFX: ${p.soundEffects.map((s) => s.text).join(', ')}\n`;
      }

      script += `\n--------------------------------------------------------\n\n`;
    });

    script += `[END OF PAGE ONE]\nTO BE CONTINUED...`;
    return script;
  };

  const handleCopy = () => {
    const text = generateScriptText();
    navigator.clipboard.writeText(text);
    setCopied(true);
    playComicSFX('CLICK');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const text = generateScriptText();
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${comic.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_script.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    playComicSFX('POW');
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-6">
      {/* Script Header Banner */}
      <div className="bg-white border-4 border-black comic-shadow-lg p-5 mb-6 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-zinc-500 mb-1">
            <FileText className="w-4 h-4 text-amber-500" />
            STANDARD COMIC WRITER SCRIPT FORMAT
          </div>
          <h2 className="font-comic-title text-3xl text-black">
            {comic.title} <span className="text-zinc-500 text-xl font-mono">({comic.issue})</span>
          </h2>
          <p className="text-xs font-mono text-zinc-600 mt-1 max-w-xl">
            Generated script breakdown formatted for comic editors, pencillers, and letterers.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 bg-yellow-300 hover:bg-yellow-400 text-black font-bold text-xs px-3 py-2 border-2 border-black comic-shadow-sm transition-transform active:translate-y-0.5 cursor-pointer uppercase"
          >
            {copied ? <Check className="w-4 h-4 text-green-700" /> : <Copy className="w-4 h-4" />}
            {copied ? 'Copied!' : 'Copy Script'}
          </button>

          <button
            onClick={handleDownload}
            className="flex items-center gap-1.5 bg-black hover:bg-zinc-800 text-white font-bold text-xs px-3 py-2 border-2 border-black comic-shadow-sm transition-transform active:translate-y-0.5 cursor-pointer uppercase"
          >
            <Download className="w-4 h-4" />
            Download .txt
          </button>

          <button
            onClick={onOpenCanvas}
            className="flex items-center gap-1.5 bg-blue-500 hover:bg-blue-600 text-white font-bold text-xs px-3 py-2 border-2 border-black comic-shadow-sm transition-transform active:translate-y-0.5 cursor-pointer uppercase"
          >
            <BookOpen className="w-4 h-4" />
            Visual Studio
          </button>
        </div>
      </div>

      {/* Script Document Sheet (Courier / Typewriter aesthetic) */}
      <div className="bg-[#fcfbf9] border-4 border-black comic-shadow-xl p-6 sm:p-10 font-mono text-xs sm:text-sm text-zinc-900 space-y-6 leading-relaxed">
        {/* Title Block */}
        <div className="border-b-2 border-zinc-300 pb-4 text-center">
          <h1 className="font-bold text-xl sm:text-2xl text-black tracking-wider uppercase">
            {comic.title}
          </h1>
          <p className="font-bold text-zinc-600">{comic.issue}</p>
          <div className="mt-2 text-xs text-zinc-500">
            Genre: {comic.genre} | Style: {comic.artStyle}
          </div>
          <div className="mt-3 p-3 bg-amber-50 border border-amber-200 text-left text-xs italic">
            <strong>LOGLINE:</strong> {comic.synopsis}
          </div>
        </div>

        {/* Characters Breakdown */}
        <div>
          <h3 className="font-bold text-xs uppercase tracking-wider text-black border-b border-black pb-1 mb-2">
            CHARACTER ROSTER & VISUAL DESIGN
          </h3>
          <ul className="space-y-2">
            {comic.characters.map((ch) => (
              <li key={ch.id} className="text-xs">
                <strong className="text-black uppercase">{ch.name}</strong> ({ch.role}):{' '}
                <span className="text-zinc-700">{ch.visualDescription}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Page 1 Breakdown */}
        <div className="pt-4 border-t-2 border-black">
          <div className="bg-black text-amber-300 font-bold px-3 py-1 uppercase tracking-widest text-xs inline-block mb-4">
            PAGE ONE
          </div>

          <div className="space-y-8">
            {comic.panels.map((p) => (
              <div key={p.id} className="bg-white border-2 border-zinc-300 p-4 rounded-xs">
                {/* Panel Header */}
                <div className="flex items-center justify-between border-b border-zinc-200 pb-1.5 mb-2 font-bold">
                  <span className="text-red-600 uppercase text-xs">
                    PANEL {p.panelNumber}
                  </span>
                  <span className="text-zinc-500 text-[11px] uppercase">
                    CAMERA: [{p.cameraShot.replace('_', ' ')}]
                  </span>
                </div>

                {/* Scene & Art Prompt */}
                <p className="text-zinc-900 mb-2">
                  <strong className="text-black">SCENE:</strong> {p.sceneDescription}
                </p>
                <p className="text-zinc-600 text-xs italic mb-4 bg-zinc-50 p-2 border-l-2 border-amber-400">
                  <strong className="not-italic text-zinc-800">ARTIST NOTE:</strong> {p.visualPrompt}
                </p>

                {/* Caption */}
                {p.caption && (
                  <div className="mb-3 bg-yellow-100/70 border border-yellow-300 p-2 text-xs">
                    <strong className="uppercase text-amber-900 block text-[10px]">CAPTION:</strong>
                    "{p.caption}"
                  </div>
                )}

                {/* Dialogue */}
                <div className="space-y-2 pl-4 border-l-2 border-zinc-300">
                  {p.speechBubbles.map((sb) => (
                    <div key={sb.id} className="text-xs">
                      <strong className="uppercase text-blue-900">{sb.speaker}</strong>
                      {sb.type !== 'speech' && (
                        <span className="text-zinc-400 text-[10px] ml-1">({sb.type.toUpperCase()})</span>
                      )}
                      : <span className="font-sans font-semibold text-zinc-800">"{sb.text}"</span>
                    </div>
                  ))}
                </div>

                {/* Sound FX */}
                {p.soundEffects.length > 0 && (
                  <div className="mt-3 pt-2 border-t border-dashed border-zinc-200 text-xs font-bold text-red-600">
                    SFX: {p.soundEffects.map((s) => s.text).join(', ')}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="text-center pt-6 border-t-2 border-black font-bold uppercase text-xs">
          [END OF PAGE ONE - TO BE CONTINUED]
        </div>
      </div>
    </div>
  );
};
