import React, { useState } from 'react';
import { 
  X, 
  Printer, 
  Download, 
  Upload, 
  FileCode, 
  Check, 
  Share2, 
  Sparkles 
} from 'lucide-react';
import { ComicBook } from '../types/comic';
import { playComicSFX } from '../utils/soundEffectsAudio';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  comic: ComicBook;
  onImportComic: (comic: ComicBook) => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  comic,
  onImportComic,
}) => {
  const [jsonCopied, setJsonCopied] = useState(false);
  const [importError, setImportError] = useState<string | null>(null);

  if (!isOpen) return null;

  // Print comic
  const handlePrint = () => {
    playComicSFX('POW');
    window.print();
  };

  // Export JSON file
  const handleDownloadJson = () => {
    const jsonStr = JSON.stringify(comic, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${comic.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.comic.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    playComicSFX('CLICK');
  };

  // Copy JSON to clipboard
  const handleCopyJson = () => {
    navigator.clipboard.writeText(JSON.stringify(comic, null, 2));
    setJsonCopied(true);
    playComicSFX('CLICK');
    setTimeout(() => setJsonCopied(false), 2000);
  };

  // Import JSON file
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (!parsed.title || !parsed.panels) {
          throw new Error('Invalid Comic JSON file: missing title or panels.');
        }
        onImportComic(parsed);
        playComicSFX('POW');
        onClose();
      } catch (err: any) {
        setImportError(err.message || 'Failed to read file.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-xl bg-amber-50 border-4 border-black comic-shadow-xl p-6 sm:p-8 my-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 bg-white hover:bg-red-50 text-black border-2 border-black p-1.5 comic-shadow-sm cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="mb-6 border-b-2 border-black pb-3">
          <div className="bg-black text-amber-400 font-mono text-[10px] px-2 py-0.5 uppercase tracking-widest font-bold inline-block mb-1">
            PUBLISHING & EXPORT
          </div>
          <h2 className="font-comic-title text-3xl text-black">
            EXPORT COMIC BOOK
          </h2>
          <p className="font-comic-body font-bold text-zinc-600 text-sm mt-0.5">
            Export <span className="text-black font-extrabold">{comic.title}</span> as print-ready artwork, screenplay script, or JSON project file.
          </p>
        </div>

        {importError && (
          <div className="mb-4 bg-red-100 border-2 border-red-600 text-red-900 p-2.5 text-xs font-mono font-bold">
            {importError}
          </div>
        )}

        {/* Export Options Grid */}
        <div className="space-y-3 mb-6">
          {/* Print / Save to PDF */}
          <button
            onClick={handlePrint}
            className="w-full bg-white hover:bg-amber-100 border-2 border-black p-4 comic-shadow-sm flex items-center justify-between text-left transition-all hover:translate-x-1 cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-yellow-400 border-2 border-black flex items-center justify-center">
                <Printer className="w-5 h-5 text-black" />
              </div>
              <div>
                <h4 className="font-comic-title text-lg text-black">PRINT / SAVE AS PDF</h4>
                <p className="text-xs text-zinc-600 font-sans">
                  Open print dialog to save full comic page as a high-res PDF or print physical issue.
                </p>
              </div>
            </div>
            <span className="font-mono text-xs font-bold bg-amber-200 border border-black px-2 py-1">
              PRINT
            </span>
          </button>

          {/* Download Comic Project JSON */}
          <button
            onClick={handleDownloadJson}
            className="w-full bg-white hover:bg-amber-100 border-2 border-black p-4 comic-shadow-sm flex items-center justify-between text-left transition-all hover:translate-x-1 cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-400 border-2 border-black flex items-center justify-center">
                <Download className="w-5 h-5 text-white" />
              </div>
              <div>
                <h4 className="font-comic-title text-lg text-black">DOWNLOAD PROJECT FILE (.JSON)</h4>
                <p className="text-xs text-zinc-600 font-sans">
                  Saves all panels, speech bubbles, sound effects, and character lore for reloading anytime.
                </p>
              </div>
            </div>
            <span className="font-mono text-xs font-bold bg-blue-200 border border-black px-2 py-1">
              JSON
            </span>
          </button>

          {/* Copy JSON data */}
          <button
            onClick={handleCopyJson}
            className="w-full bg-white hover:bg-amber-100 border-2 border-black p-4 comic-shadow-sm flex items-center justify-between text-left transition-all hover:translate-x-1 cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-purple-400 border-2 border-black flex items-center justify-center">
                <FileCode className="w-5 h-5 text-white" />
              </div>
              <div>
                <h4 className="font-comic-title text-lg text-black">COPY RAW COMIC DATA</h4>
                <p className="text-xs text-zinc-600 font-sans">
                  Copy structured JSON directly to clipboard for developers or external apps.
                </p>
              </div>
            </div>
            <span className="font-mono text-xs font-bold bg-purple-200 border border-black px-2 py-1">
              {jsonCopied ? 'COPIED!' : 'COPY'}
            </span>
          </button>
        </div>

        {/* Import Existing Project */}
        <div className="border-t-2 border-black pt-4">
          <label className="font-comic-title text-sm text-black tracking-wide block mb-2">
            RESTORE / IMPORT COMIC PROJECT:
          </label>
          <label className="flex items-center justify-center gap-2 w-full bg-white hover:bg-zinc-50 border-2 border-dashed border-black p-3 text-xs font-mono font-bold cursor-pointer transition-colors">
            <Upload className="w-4 h-4 text-zinc-600" />
            <span>Select .json file to restore</span>
            <input
              type="file"
              accept=".json"
              onChange={handleFileUpload}
              className="hidden"
            />
          </label>
        </div>
      </div>
    </div>
  );
};
