import React, { useState, useEffect } from 'react';
import { 
  X, 
  ChevronLeft, 
  ChevronRight, 
  Play, 
  Pause, 
  Maximize2, 
  Minimize2,
  Volume2,
  VolumeX,
  Sparkles
} from 'lucide-react';
import { ComicBook } from '../types/comic';
import { playComicSFX } from '../utils/soundEffectsAudio';

interface ComicReaderModalProps {
  isOpen: boolean;
  onClose: () => void;
  comic: ComicBook;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export const ComicReaderModal: React.FC<ComicReaderModalProps> = ({
  isOpen,
  onClose,
  comic,
  soundEnabled,
  onToggleSound,
}) => {
  const [currentPanelIndex, setCurrentPanelIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [viewMode, setViewMode] = useState<'cinematic' | 'page'>('cinematic');

  const totalPanels = comic.panels.length;
  const currentPanel = comic.panels[currentPanelIndex];

  // Auto-play timer
  useEffect(() => {
    let timer: any;
    if (isPlaying && isOpen) {
      timer = setInterval(() => {
        setCurrentPanelIndex((prev) => {
          if (prev >= totalPanels - 1) {
            setIsPlaying(false);
            return prev;
          }
          const next = prev + 1;
          const nextPanel = comic.panels[next];
          if (nextPanel.soundEffects[0]) {
            playComicSFX(nextPanel.soundEffects[0].text);
          } else {
            playComicSFX('PAGE');
          }
          return next;
        });
      }, 4200);
    }
    return () => clearInterval(timer);
  }, [isPlaying, isOpen, totalPanels, comic.panels]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;
      if (e.key === 'ArrowRight' || e.key === ' ') {
        e.preventDefault();
        handleNext();
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        handlePrev();
      } else if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, currentPanelIndex, totalPanels]);

  if (!isOpen || !currentPanel) return null;

  const handleNext = () => {
    if (currentPanelIndex < totalPanels - 1) {
      const next = currentPanelIndex + 1;
      setCurrentPanelIndex(next);
      const nextPanel = comic.panels[next];
      if (nextPanel.soundEffects[0]) {
        playComicSFX(nextPanel.soundEffects[0].text);
      } else {
        playComicSFX('PAGE');
      }
    }
  };

  const handlePrev = () => {
    if (currentPanelIndex > 0) {
      setCurrentPanelIndex(currentPanelIndex - 1);
      playComicSFX('PAGE');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col justify-between select-none">
      {/* Top Controls Bar */}
      <div className="bg-zinc-950/90 border-b-2 border-zinc-800 px-4 py-2.5 flex items-center justify-between text-white z-20">
        <div className="flex items-center gap-3">
          <div className="font-comic-title text-xl text-yellow-400 tracking-wider">
            {comic.title}
          </div>
          <span className="text-zinc-500 hidden sm:inline">|</span>
          <span className="text-xs font-mono text-zinc-400 hidden sm:inline">
            {comic.issue}
          </span>
        </div>

        <div className="flex items-center gap-3">
          {/* Panel indicator */}
          <span className="bg-zinc-800 border border-zinc-700 px-2.5 py-1 text-xs font-mono text-amber-300 font-bold">
            PANEL {currentPanelIndex + 1} OF {totalPanels}
          </span>

          {/* Auto play toggle */}
          <button
            onClick={() => {
              setIsPlaying(!isPlaying);
              playComicSFX('CLICK');
            }}
            className={`flex items-center gap-1 text-xs font-bold px-2.5 py-1 rounded-xs border cursor-pointer ${
              isPlaying
                ? 'bg-amber-400 text-black border-amber-300'
                : 'bg-zinc-800 text-white border-zinc-700 hover:bg-zinc-700'
            }`}
          >
            {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline">{isPlaying ? 'Pause' : 'Auto-Play'}</span>
          </button>

          {/* Sound Toggle */}
          <button
            onClick={() => {
              onToggleSound();
              if (!soundEnabled) playComicSFX('POW');
            }}
            className="p-1.5 hover:bg-zinc-800 rounded-xs text-zinc-400 hover:text-white cursor-pointer"
            title={soundEnabled ? 'Mute' : 'Unmute'}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-amber-400" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* Close */}
          <button
            onClick={onClose}
            className="p-1.5 bg-red-600 hover:bg-red-500 text-white border border-black rounded-xs cursor-pointer"
            title="Exit Reader (Esc)"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Panel Cinema Viewport */}
      <div className="flex-1 relative flex items-center justify-center p-4 sm:p-8 overflow-hidden bg-zinc-950">
        <div className="relative max-w-4xl w-full max-h-[75vh] aspect-[4/3] bg-black border-4 border-amber-400 comic-shadow-xl overflow-hidden rounded-xs">
          {/* Visual Artwork */}
          {currentPanel.imageUrl ? (
            <img
              src={currentPanel.imageUrl}
              alt={currentPanel.sceneDescription}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          ) : currentPanel.svgArt ? (
            <div
              className="w-full h-full flex items-center justify-center [&>svg]:w-full [&>svg]:h-full [&>svg]:object-cover"
              dangerouslySetInnerHTML={{ __html: currentPanel.svgArt }}
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-zinc-900 to-black p-8 flex flex-col justify-center items-center text-center relative bg-halftone">
              <Sparkles className="w-12 h-12 text-amber-400 mb-3 animate-spin" />
              <p className="font-comic-title text-2xl text-white max-w-md">
                "{currentPanel.sceneDescription}"
              </p>
              <p className="text-xs text-zinc-400 font-mono mt-2 italic max-w-sm">
                {currentPanel.visualPrompt}
              </p>
            </div>
          )}

          {/* Halftone Overlay */}
          <div className="absolute inset-0 bg-halftone opacity-20 pointer-events-none" />

          {/* Narrator Caption */}
          {currentPanel.caption && (
            <div
              className={`absolute z-20 max-w-[85%] border-2 border-black p-2 font-bold uppercase tracking-wider text-xs leading-tight comic-shadow-sm ${
                currentPanel.captionTheme === 'dark_noir'
                  ? 'bg-black text-amber-300 border-amber-400/50'
                  : currentPanel.captionTheme === 'manga_white'
                  ? 'bg-white text-black'
                  : 'bg-amber-300 text-black'
              } ${
                currentPanel.captionPosition === 'bottom-left'
                  ? 'bottom-4 left-4'
                  : currentPanel.captionPosition === 'bottom-right'
                  ? 'bottom-4 right-4'
                  : currentPanel.captionPosition === 'top-right'
                  ? 'top-4 right-4'
                  : 'top-4 left-4'
              }`}
            >
              {currentPanel.caption}
            </div>
          )}

          {/* Speech Bubbles */}
          {currentPanel.speechBubbles.map((bubble) => (
            <div
              key={bubble.id}
              style={{
                left: `${bubble.x}%`,
                top: `${bubble.y}%`,
                transform: 'translate(-50%, -50%)',
              }}
              className={`absolute z-20 max-w-[240px] p-2.5 border-2 border-black comic-shadow-sm font-comic-body font-bold text-sm ${
                bubble.type === 'shout'
                  ? 'bg-amber-100 text-red-700 border-red-600 font-extrabold uppercase scale-110'
                  : bubble.type === 'thought'
                  ? 'bg-white text-slate-800 rounded-3xl thought-bubble'
                  : bubble.type === 'whisper'
                  ? 'bg-white/90 text-zinc-600 border-dashed rounded-xl'
                  : bubble.type === 'radio'
                  ? 'bg-cyan-50 text-cyan-950 border-cyan-800 rounded-lg'
                  : 'bg-white text-black rounded-2xl'
              } ${bubble.tailDirection === 'bottom-left' ? 'bubble-tail-bottom-left' : ''} ${
                bubble.tailDirection === 'bottom-right' ? 'bubble-tail-bottom-right' : ''
              }`}
            >
              {bubble.speaker && (
                <span className="block text-[10px] font-sans uppercase tracking-wider text-zinc-500 mb-0.5 leading-none">
                  {bubble.speaker}:
                </span>
              )}
              <p className="leading-snug">{bubble.text}</p>
            </div>
          ))}

          {/* Sound Effects */}
          {currentPanel.soundEffects.map((sfx) => (
            <div
              key={sfx.id}
              style={{
                left: `${sfx.x}%`,
                top: `${sfx.y}%`,
                transform: `translate(-50%, -50%) rotate(${sfx.rotation || 0}deg)`,
              }}
              onClick={() => playComicSFX(sfx.text)}
              className="absolute z-25 font-comic-title text-4xl sm:text-5xl tracking-wider cursor-pointer transition-transform hover:scale-110 active:scale-95 select-none"
              title="Click to hear sound effect!"
            >
              <div
                className={`px-4 py-2 border-2 comic-shadow-lg font-extrabold ${
                  sfx.style === 'shock_red'
                    ? 'bg-red-600 text-white border-black'
                    : sfx.style === 'neon_cyan'
                    ? 'bg-cyan-400 text-black border-black'
                    : sfx.style === 'dark_purple'
                    ? 'bg-purple-800 text-amber-300 border-black'
                    : 'bg-yellow-400 text-red-600 border-black'
                } clip-starburst-sharp`}
              >
                {sfx.text}
              </div>
            </div>
          ))}
        </div>

        {/* Previous / Next Arrow Controls */}
        <button
          onClick={handlePrev}
          disabled={currentPanelIndex === 0}
          className="absolute left-2 sm:left-6 top-1/2 -translate-y-1/2 bg-yellow-400 hover:bg-yellow-300 disabled:opacity-30 disabled:pointer-events-none text-black p-3 border-2 border-black comic-shadow-lg transition-transform active:scale-95 cursor-pointer"
          title="Previous panel (Left arrow)"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>

        <button
          onClick={handleNext}
          disabled={currentPanelIndex === totalPanels - 1}
          className="absolute right-2 sm:right-6 top-1/2 -translate-y-1/2 bg-yellow-400 hover:bg-yellow-300 disabled:opacity-30 disabled:pointer-events-none text-black p-3 border-2 border-black comic-shadow-lg transition-transform active:scale-95 cursor-pointer"
          title="Next panel (Right arrow / Space)"
        >
          <ChevronRight className="w-6 h-6" />
        </button>
      </div>

      {/* Bottom Thumbnail Strip & Navigation Bar */}
      <div className="bg-zinc-950 border-t-2 border-zinc-800 px-4 py-2 flex items-center justify-between text-white text-xs">
        <div className="text-zinc-500 font-mono text-[11px] hidden md:block">
          Use ← / → Arrow keys or Spacebar to flip panels
        </div>

        {/* Dots / Thumbnail navigation */}
        <div className="flex items-center gap-2 mx-auto">
          {comic.panels.map((p, idx) => (
            <button
              key={p.id}
              onClick={() => {
                setCurrentPanelIndex(idx);
                playComicSFX('CLICK');
              }}
              className={`w-6 h-6 rounded-xs font-mono font-bold text-[10px] flex items-center justify-center transition-all cursor-pointer ${
                idx === currentPanelIndex
                  ? 'bg-amber-400 text-black font-black scale-110'
                  : 'bg-zinc-800 text-zinc-400 hover:bg-zinc-700'
              }`}
            >
              {idx + 1}
            </button>
          ))}
        </div>

        <div className="text-right">
          <button
            onClick={() => {
              if (currentPanelIndex < totalPanels - 1) {
                handleNext();
              } else {
                setCurrentPanelIndex(0);
                playComicSFX('PAGE');
              }
            }}
            className="text-amber-400 hover:underline font-bold text-xs uppercase"
          >
            {currentPanelIndex < totalPanels - 1 ? 'Next Panel →' : 'Replay From Start ↻'}
          </button>
        </div>
      </div>
    </div>
  );
};
