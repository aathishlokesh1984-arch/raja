import React, { useState } from 'react';
import { 
  Sparkles, 
  MessageSquare, 
  Zap, 
  Wand2, 
  Trash2, 
  Move, 
  Camera, 
  Edit3,
  Loader2,
  Check,
  X,
  Volume2
} from 'lucide-react';
import { ComicPanel, SpeechBubble, SoundEffect, BubbleType, SoundEffectStyle } from '../types/comic';
import { playComicSFX } from '../utils/soundEffectsAudio';

interface ComicPanelItemProps {
  panel: ComicPanel;
  genre: string;
  artStyle: string;
  onUpdatePanel: (updated: ComicPanel) => void;
  onDeletePanel: () => void;
  onGenerateSvgArt: (panelId: string) => Promise<void>;
  onGenerateImageArt: (panelId: string) => Promise<void>;
  isGeneratingArt?: boolean;
}

export const ComicPanelItem: React.FC<ComicPanelItemProps> = ({
  panel,
  genre,
  artStyle,
  onUpdatePanel,
  onDeletePanel,
  onGenerateSvgArt,
  onGenerateImageArt,
  isGeneratingArt = false,
}) => {
  const [isEditingCaption, setIsEditingCaption] = useState(false);
  const [captionDraft, setCaptionDraft] = useState(panel.caption || '');
  const [activeBubbleId, setActiveBubbleId] = useState<string | null>(null);
  const [activeSfxId, setActiveSfxId] = useState<string | null>(null);
  const [showAiRefinePrompt, setShowAiRefinePrompt] = useState(false);
  const [refineInstruction, setRefineInstruction] = useState('');
  const [isRefining, setIsRefining] = useState(false);

  // Helper for sound effect styles
  const getSfxBg = (style: SoundEffectStyle) => {
    switch (style) {
      case 'shock_red':
        return 'bg-red-600 text-white border-black';
      case 'neon_cyan':
        return 'bg-cyan-400 text-black border-black';
      case 'dark_purple':
        return 'bg-purple-800 text-amber-300 border-black';
      case 'speed_white':
        return 'bg-white text-black border-black';
      case 'burst_yellow':
      default:
        return 'bg-yellow-400 text-red-600 border-black';
    }
  };

  // Add new speech bubble
  const handleAddBubble = () => {
    const newBubble: SpeechBubble = {
      id: `sb-${Date.now()}`,
      speaker: 'Character',
      text: 'New dialogue line!',
      type: 'speech',
      x: 35 + Math.floor(Math.random() * 20),
      y: 30 + Math.floor(Math.random() * 20),
      tailDirection: 'bottom-left',
    };
    onUpdatePanel({
      ...panel,
      speechBubbles: [...panel.speechBubbles, newBubble],
    });
    setActiveBubbleId(newBubble.id);
    playComicSFX('CLICK');
  };

  // Add new Sound Effect
  const handleAddSfx = (text: string = 'POW!') => {
    const newSfx: SoundEffect = {
      id: `sfx-${Date.now()}`,
      text,
      x: 30 + Math.floor(Math.random() * 30),
      y: 40 + Math.floor(Math.random() * 20),
      rotation: Math.floor(Math.random() * 24) - 12,
      style: 'burst_yellow',
      size: 'lg',
    };
    onUpdatePanel({
      ...panel,
      soundEffects: [...panel.soundEffects, newSfx],
    });
    setActiveSfxId(newSfx.id);
    playComicSFX(text);
  };

  // AI Refine Panel Dialog
  const handleAiRefine = async () => {
    if (!refineInstruction.trim()) return;
    setIsRefining(true);
    try {
      const res = await fetch('/api/comic/refine-panel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          panel,
          instruction: refineInstruction,
          genre,
        }),
      });
      const data = await res.json();
      if (data.success && data.panel) {
        onUpdatePanel(data.panel);
        setShowAiRefinePrompt(false);
        setRefineInstruction('');
        playComicSFX('POW');
      }
    } catch (e) {
      console.error('Refine failed:', e);
    } finally {
      setIsRefining(false);
    }
  };

  return (
    <div className="group/panel relative flex flex-col bg-white border-4 border-black comic-shadow-lg transition-all hover:comic-shadow-xl overflow-hidden rounded-xs">
      {/* Panel Top Meta Bar */}
      <div className="bg-black text-white px-2 py-1 flex items-center justify-between text-[11px] font-mono select-none">
        <div className="flex items-center gap-2">
          <span className="bg-amber-400 text-black px-1.5 py-0.2 font-black uppercase text-[10px]">
            PANEL {panel.panelNumber}
          </span>
          <span className="text-zinc-400 capitalize hidden sm:inline">
            <Camera className="w-3 h-3 inline mr-1 text-zinc-500" />
            {panel.cameraShot.replace('_', ' ')}
          </span>
        </div>

        {/* Panel Action Toolbar */}
        <div className="flex items-center gap-1.5 opacity-90 group-hover/panel:opacity-100 transition-opacity">
          <button
            onClick={() => onGenerateSvgArt(panel.id)}
            disabled={isGeneratingArt}
            title="Generate custom Vector SVG comic art with Gemini 3.8 Flash"
            className="flex items-center gap-1 bg-amber-400 hover:bg-amber-300 text-black px-2 py-0.5 font-bold rounded-xs cursor-pointer text-[10px] uppercase transition-colors"
          >
            {isGeneratingArt ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
            <span className="hidden md:inline">Vector</span> Art
          </button>

          <button
            onClick={() => onGenerateImageArt(panel.id)}
            disabled={isGeneratingArt}
            title="Generate AI Image with Gemini"
            className="flex items-center gap-1 bg-blue-500 hover:bg-blue-400 text-white px-2 py-0.5 font-bold rounded-xs cursor-pointer text-[10px] uppercase transition-colors"
          >
            <Sparkles className="w-3 h-3" />
            <span className="hidden md:inline">AI</span> Image
          </button>

          <button
            onClick={handleAddBubble}
            title="Add Speech Bubble"
            className="p-1 hover:bg-zinc-800 text-amber-300 rounded-xs cursor-pointer"
          >
            <MessageSquare className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => handleAddSfx('POW!')}
            title="Add Sound FX (POW!)"
            className="p-1 hover:bg-zinc-800 text-red-400 rounded-xs cursor-pointer"
          >
            <Zap className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => setShowAiRefinePrompt(!showAiRefinePrompt)}
            title="AI Dialogue & Scene Polish"
            className="p-1 hover:bg-zinc-800 text-purple-300 rounded-xs cursor-pointer"
          >
            <Wand2 className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={onDeletePanel}
            title="Delete Panel"
            className="p-1 hover:bg-red-800 text-red-300 rounded-xs cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* AI Refine Dialog Prompt Bar */}
      {showAiRefinePrompt && (
        <div className="bg-amber-100 border-b-2 border-black p-2 flex items-center gap-2 text-xs">
          <Wand2 className="w-4 h-4 text-purple-600 shrink-0" />
          <input
            type="text"
            value={refineInstruction}
            onChange={(e) => setRefineInstruction(e.target.value)}
            placeholder="e.g. 'Make dialogue punchier', 'Add a shocking plot twist', 'Make it humorous'..."
            className="flex-1 bg-white border border-black px-2 py-1 text-xs rounded-xs outline-none font-sans"
            onKeyDown={(e) => e.key === 'Enter' && handleAiRefine()}
          />
          <button
            onClick={handleAiRefine}
            disabled={isRefining || !refineInstruction.trim()}
            className="bg-black hover:bg-zinc-800 text-white px-2.5 py-1 font-bold text-xs rounded-xs cursor-pointer flex items-center gap-1"
          >
            {isRefining ? <Loader2 className="w-3 h-3 animate-spin" /> : 'Rewrite'}
          </button>
          <button
            onClick={() => setShowAiRefinePrompt(false)}
            className="p-1 hover:bg-amber-200 text-zinc-600 cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Main Panel Visual Artwork Area */}
      <div className="relative w-full aspect-[4/3] bg-zinc-950 overflow-hidden select-none">
        {/* Render Artwork: Image, SVG, or Stylized Fallback */}
        {panel.imageUrl ? (
          <img
            src={panel.imageUrl}
            alt={panel.sceneDescription}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
        ) : panel.svgArt ? (
          <div
            className="w-full h-full flex items-center justify-center [&>svg]:w-full [&>svg]:h-full [&>svg]:object-cover"
            dangerouslySetInnerHTML={{ __html: panel.svgArt }}
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-zinc-900 via-slate-800 to-black p-6 flex flex-col justify-between relative bg-halftone">
            <div className="absolute inset-0 speed-lines-radial opacity-30 pointer-events-none" />
            <div className="text-zinc-400 text-xs font-mono max-w-sm relative z-10">
              <span className="text-amber-400 font-bold block mb-1">PROMPT:</span>
              <p className="line-clamp-4 text-zinc-300 italic">{panel.visualPrompt}</p>
            </div>

            <div className="relative z-10 flex items-center justify-center">
              <button
                onClick={() => onGenerateSvgArt(panel.id)}
                disabled={isGeneratingArt}
                className="bg-amber-400 hover:bg-amber-300 text-black font-comic-title text-sm px-4 py-2 border-2 border-black comic-shadow-sm flex items-center gap-2 cursor-pointer transition-transform hover:scale-105 active:scale-95"
              >
                {isGeneratingArt ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    ILLUSTRATING WITH GEMINI...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-black fill-black" />
                    GENERATE VECTOR ARTWORK
                  </>
                )}
              </button>
            </div>

            <div className="text-[10px] text-zinc-500 font-mono text-right relative z-10">
              {panel.sceneDescription.slice(0, 70)}...
            </div>
          </div>
        )}

        {/* Loading Overlay */}
        {isGeneratingArt && (
          <div className="absolute inset-0 bg-black/70 backdrop-blur-xs flex flex-col items-center justify-center text-amber-300 z-30">
            <Loader2 className="w-8 h-8 animate-spin text-amber-400 mb-2" />
            <span className="font-comic-title text-xl tracking-wider animate-pulse">
              GEMINI IS INKING THIS PANEL...
            </span>
            <span className="text-xs font-mono text-zinc-400 mt-1">Applying speed lines & colors</span>
          </div>
        )}

        {/* Halftone Texture Overlay on panel */}
        <div className="absolute inset-0 bg-halftone pointer-events-none opacity-20" />

        {/* Narrator Caption Box (Editable) */}
        {panel.caption && (
          <div
            className={`absolute z-20 max-w-[85%] border-2 border-black p-1.5 font-bold uppercase tracking-wider text-[11px] leading-tight comic-shadow-sm transition-all ${
              panel.captionTheme === 'dark_noir'
                ? 'bg-black text-amber-300 border-amber-400/50'
                : panel.captionTheme === 'manga_white'
                ? 'bg-white text-black'
                : 'bg-amber-300 text-black'
            } ${
              panel.captionPosition === 'bottom-left'
                ? 'bottom-2 left-2'
                : panel.captionPosition === 'bottom-right'
                ? 'bottom-2 right-2'
                : panel.captionPosition === 'top-right'
                ? 'top-2 right-2'
                : 'top-2 left-2'
            }`}
          >
            {isEditingCaption ? (
              <div className="flex items-center gap-1">
                <input
                  type="text"
                  value={captionDraft}
                  onChange={(e) => setCaptionDraft(e.target.value)}
                  className="bg-white text-black px-1 py-0.5 text-[11px] border border-black font-sans uppercase font-bold outline-none"
                  autoFocus
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      onUpdatePanel({ ...panel, caption: captionDraft });
                      setIsEditingCaption(false);
                    }
                  }}
                />
                <button
                  onClick={() => {
                    onUpdatePanel({ ...panel, caption: captionDraft });
                    setIsEditingCaption(false);
                  }}
                  className="bg-black text-white p-0.5 cursor-pointer"
                >
                  <Check className="w-3 h-3" />
                </button>
              </div>
            ) : (
              <div
                onClick={() => {
                  setCaptionDraft(panel.caption || '');
                  setIsEditingCaption(true);
                }}
                className="cursor-pointer hover:opacity-80 flex items-center gap-1 font-comic-body"
                title="Click to edit narrator caption"
              >
                <span>{panel.caption}</span>
                <Edit3 className="w-2.5 h-2.5 opacity-40 hover:opacity-100 ml-1" />
              </div>
            )}
          </div>
        )}

        {/* Speech Bubbles */}
        {panel.speechBubbles.map((bubble) => {
          const isSelected = activeBubbleId === bubble.id;
          return (
            <div
              key={bubble.id}
              style={{
                left: `${bubble.x}%`,
                top: `${bubble.y}%`,
                transform: 'translate(-50%, -50%)',
              }}
              className={`absolute z-20 max-w-[210px] p-2 border-2 border-black comic-shadow-sm transition-transform cursor-move font-comic-body font-bold text-xs select-none ${
                bubble.type === 'shout'
                  ? 'bg-amber-100 text-red-700 border-red-600 font-extrabold uppercase scale-105'
                  : bubble.type === 'thought'
                  ? 'bg-white text-slate-800 rounded-3xl thought-bubble'
                  : bubble.type === 'whisper'
                  ? 'bg-white/90 text-zinc-600 border-dashed rounded-xl'
                  : bubble.type === 'radio'
                  ? 'bg-cyan-50 text-cyan-950 border-cyan-800 rounded-lg'
                  : 'bg-white text-black rounded-2xl'
              } ${bubble.tailDirection === 'bottom-left' ? 'bubble-tail-bottom-left' : ''} ${
                bubble.tailDirection === 'bottom-right' ? 'bubble-tail-bottom-right' : ''
              } ${isSelected ? 'ring-2 ring-blue-500 scale-105' : ''}`}
              onClick={(e) => {
                e.stopPropagation();
                setActiveBubbleId(isSelected ? null : bubble.id);
                playComicSFX('CLICK');
              }}
            >
              {/* Speaker Tag */}
              {bubble.speaker && (
                <span className="block text-[9px] font-sans uppercase tracking-wider text-zinc-500 mb-0.5 leading-none">
                  {bubble.speaker}:
                </span>
              )}

              {/* Editable Text Area */}
              {isSelected ? (
                <div className="space-y-1.5" onClick={(e) => e.stopPropagation()}>
                  <textarea
                    value={bubble.text}
                    onChange={(e) => {
                      const updatedBubbles = panel.speechBubbles.map((b) =>
                        b.id === bubble.id ? { ...b, text: e.target.value } : b
                      );
                      onUpdatePanel({ ...panel, speechBubbles: updatedBubbles });
                    }}
                    className="w-full bg-amber-50 border border-black p-1 text-xs outline-none resize-none font-comic-body"
                    rows={2}
                  />

                  {/* Bubble Type and Tail Selectors */}
                  <div className="flex items-center justify-between text-[10px] pt-1 border-t border-zinc-200">
                    <select
                      value={bubble.type}
                      onChange={(e) => {
                        const updatedBubbles = panel.speechBubbles.map((b) =>
                          b.id === bubble.id ? { ...b, type: e.target.value as BubbleType } : b
                        );
                        onUpdatePanel({ ...panel, speechBubbles: updatedBubbles });
                      }}
                      className="bg-white border border-black text-[10px] py-0.5 px-1 rounded-xs"
                    >
                      <option value="speech">Speech</option>
                      <option value="shout">Shout!</option>
                      <option value="thought">Thought</option>
                      <option value="whisper">Whisper</option>
                      <option value="radio">Radio/Comm</option>
                    </select>

                    <div className="flex items-center gap-1">
                      {/* Reposition controls */}
                      <button
                        onClick={() => {
                          const updatedBubbles = panel.speechBubbles.map((b) =>
                            b.id === bubble.id
                              ? { ...b, x: Math.max(10, b.x - 8) }
                              : b
                          );
                          onUpdatePanel({ ...panel, speechBubbles: updatedBubbles });
                        }}
                        className="px-1 bg-zinc-200 hover:bg-zinc-300 font-mono text-[9px] border border-black"
                        title="Move Left"
                      >
                        ←
                      </button>
                      <button
                        onClick={() => {
                          const updatedBubbles = panel.speechBubbles.map((b) =>
                            b.id === bubble.id
                              ? { ...b, x: Math.min(90, b.x + 8) }
                              : b
                          );
                          onUpdatePanel({ ...panel, speechBubbles: updatedBubbles });
                        }}
                        className="px-1 bg-zinc-200 hover:bg-zinc-300 font-mono text-[9px] border border-black"
                        title="Move Right"
                      >
                        →
                      </button>
                      <button
                        onClick={() => {
                          const updatedBubbles = panel.speechBubbles.map((b) =>
                            b.id === bubble.id
                              ? { ...b, y: Math.max(10, b.y - 8) }
                              : b
                          );
                          onUpdatePanel({ ...panel, speechBubbles: updatedBubbles });
                        }}
                        className="px-1 bg-zinc-200 hover:bg-zinc-300 font-mono text-[9px] border border-black"
                        title="Move Up"
                      >
                        ↑
                      </button>
                      <button
                        onClick={() => {
                          const updatedBubbles = panel.speechBubbles.map((b) =>
                            b.id === bubble.id
                              ? { ...b, y: Math.min(90, b.y + 8) }
                              : b
                          );
                          onUpdatePanel({ ...panel, speechBubbles: updatedBubbles });
                        }}
                        className="px-1 bg-zinc-200 hover:bg-zinc-300 font-mono text-[9px] border border-black"
                        title="Move Down"
                      >
                        ↓
                      </button>

                      {/* Delete Bubble */}
                      <button
                        onClick={() => {
                          const updatedBubbles = panel.speechBubbles.filter((b) => b.id !== bubble.id);
                          onUpdatePanel({ ...panel, speechBubbles: updatedBubbles });
                        }}
                        className="p-0.5 text-red-600 hover:bg-red-50 ml-1"
                        title="Delete bubble"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <p className="leading-tight text-slate-900">{bubble.text}</p>
              )}
            </div>
          );
        })}

        {/* Onomatopoeia Sound Effects */}
        {panel.soundEffects.map((sfx) => {
          const isSelected = activeSfxId === sfx.id;
          return (
            <div
              key={sfx.id}
              style={{
                left: `${sfx.x}%`,
                top: `${sfx.y}%`,
                transform: `translate(-50%, -50%) rotate(${sfx.rotation || 0}deg)`,
              }}
              onClick={(e) => {
                e.stopPropagation();
                playComicSFX(sfx.text);
                setActiveSfxId(isSelected ? null : sfx.id);
              }}
              className={`absolute z-25 font-comic-title tracking-wider cursor-pointer transition-transform hover:scale-110 active:scale-95 select-none ${
                sfx.size === 'xl'
                  ? 'text-4xl sm:text-5xl'
                  : sfx.size === 'lg'
                  ? 'text-3xl sm:text-4xl'
                  : sfx.size === 'sm'
                  ? 'text-lg sm:text-xl'
                  : 'text-2xl sm:text-3xl'
              }`}
              title="Click to trigger sound effect audio!"
            >
              {/* Comic Starburst Backing */}
              <div
                className={`px-3 py-1.5 border-2 comic-shadow-sm font-extrabold ${getSfxBg(sfx.style)} ${
                  sfx.size === 'xl' || sfx.size === 'lg' ? 'clip-starburst-sharp' : 'rounded-md'
                }`}
              >
                {sfx.text}
              </div>

              {/* Editing Controls */}
              {isSelected && (
                <div
                  className="absolute left-1/2 -bottom-9 -translate-x-1/2 bg-black text-white px-2 py-1 flex items-center gap-1.5 rounded-xs text-[10px] z-30 whitespace-nowrap"
                  onClick={(e) => e.stopPropagation()}
                >
                  <input
                    type="text"
                    value={sfx.text}
                    onChange={(e) => {
                      const updated = panel.soundEffects.map((s) =>
                        s.id === sfx.id ? { ...s, text: e.target.value } : s
                      );
                      onUpdatePanel({ ...panel, soundEffects: updated });
                    }}
                    className="bg-zinc-800 text-amber-300 font-comic-title text-xs w-20 px-1 py-0.5 outline-none"
                  />
                  <button
                    onClick={() => playComicSFX(sfx.text)}
                    className="p-1 hover:text-amber-400 cursor-pointer"
                    title="Play SFX"
                  >
                    <Volume2 className="w-3 h-3" />
                  </button>
                  <button
                    onClick={() => {
                      const updated = panel.soundEffects.filter((s) => s.id !== sfx.id);
                      onUpdatePanel({ ...panel, soundEffects: updated });
                    }}
                    className="p-1 text-red-400 hover:text-red-300 cursor-pointer"
                    title="Delete SFX"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Panel Bottom Footer - Scene Notes */}
      <div className="bg-amber-50 px-2 py-1.5 border-t-2 border-black flex items-center justify-between text-[11px] text-zinc-600 font-mono">
        <span className="truncate max-w-[70%] italic">
          "{panel.sceneDescription}"
        </span>
        <span className="text-[10px] text-zinc-400 font-bold uppercase">
          {panel.speechBubbles.length} Bubbles · {panel.soundEffects.length} SFX
        </span>
      </div>
    </div>
  );
};
