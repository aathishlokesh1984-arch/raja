import React, { useState, useEffect } from 'react';
import { 
  X, 
  Sparkles, 
  Wand2, 
  BookOpen, 
  Loader2, 
  Dices, 
  Palette, 
  Film, 
  UserPlus, 
  Check 
} from 'lucide-react';
import { Genre, ArtStyle, ComicBook } from '../types/comic';
import { playComicSFX } from '../utils/soundEffectsAudio';
import confetti from 'canvas-confetti';

interface ComicGeneratorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onComicGenerated: (comic: ComicBook) => void;
}

const INSPIRATION_PROMPTS = [
  {
    concept: 'A rogue cybernetic bounty hunter discovers their latest target is an innocent AI child holding the encryption key to the megacity.',
    genre: 'Cyberpunk Noir' as Genre,
    artStyle: 'Cyberpunk Neon & Heavy Shadows' as ArtStyle,
  },
  {
    concept: 'A hot-tempered martial arts prodigy discovers a hidden spirit forge under Tokyo, unlocking glowing celestial fist techniques.',
    genre: 'Shonen Manga' as Genre,
    artStyle: 'Action Shonen Manga (Screentone)' as ArtStyle,
  },
  {
    concept: 'An exiled sorceress and an iron knight must awaken a colossal sleeping stone dragon before an eclipse devours the kingdom.',
    genre: 'Epic Fantasy' as Genre,
    artStyle: 'Modern Comic (Bold Inks & Halftone)' as ArtStyle,
  },
  {
    concept: 'A retired legendary superhero tries running a quiet 24-hour pancake diner, but supervillains keep showing up as hungry customers.',
    genre: 'Cozy Comic Strip' as Genre,
    artStyle: 'Vintage Pop-Art (Ben-Day Dots)' as ArtStyle,
  },
  {
    concept: 'Deep space explorers enter a ghost freighter drifting near a black hole, only to realize the ship is alive and hungry.',
    genre: 'Sci-Fi Mystery' as Genre,
    artStyle: 'Dark Graphic Novel (Noir Contrast)' as ArtStyle,
  },
];

const GENRES: { id: Genre; label: string; icon: string; desc: string }[] = [
  { id: 'Superhero Modern', label: 'Superhero', icon: '🦸', desc: 'Epic heroics, capes & city-saving stakes' },
  { id: 'Cyberpunk Noir', label: 'Cyberpunk', icon: '🌆', desc: 'Rain-soaked neon, hacking & street detectives' },
  { id: 'Shonen Manga', label: 'Shonen Manga', icon: '⚡', desc: 'Fast attacks, spirit auras & screams' },
  { id: 'Epic Fantasy', label: 'Fantasy Epic', icon: '🐉', desc: 'Sorcery, ancient dragons & legendary relics' },
  { id: 'Sci-Fi Mystery', label: 'Sci-Fi', icon: '🚀', desc: 'Alien derelicts, space rifts & AI secrets' },
  { id: 'Retro Pop-Art 1960s', label: 'Vintage Pop-Art', icon: '💥', desc: 'Ben-Day halftone dots & classic 60s comics' },
  { id: 'Horror & Supernatural', label: 'Horror', icon: '👁️', desc: 'Eerie shadows, eldritch crypts & chills' },
  { id: 'Cozy Comic Strip', label: 'Slice-of-Life', icon: '☕', desc: 'Heartwarming banter & everyday humor' },
];

const ART_STYLES: ArtStyle[] = [
  'Modern Comic (Bold Inks & Halftone)',
  'Vintage Pop-Art (Ben-Day Dots)',
  'Cyberpunk Neon & Heavy Shadows',
  'Action Shonen Manga (Screentone)',
  'Dark Graphic Novel (Noir Contrast)',
];

const LOADING_MILESTONES = [
  'Conceiving logline & plot twist with Gemini...',
  'Designing hero & villain roster...',
  'Choreographing dramatic camera angles...',
  'Scripting snappy speech bubbles & dialogue...',
  'Inking explosive onomatopoeia sound effects (POW, BAM)...',
  'Assembling your comic book issue...',
];

export const ComicGeneratorModal: React.FC<ComicGeneratorModalProps> = ({
  isOpen,
  onClose,
  onComicGenerated,
}) => {
  const [concept, setConcept] = useState('');
  const [genre, setGenre] = useState<Genre>('Superhero Modern');
  const [artStyle, setArtStyle] = useState<ArtStyle>('Modern Comic (Bold Inks & Halftone)');
  const [panelCount, setPanelCount] = useState<number>(4);
  const [pacing, setPacing] = useState('action-packed');
  const [tone, setTone] = useState('Dramatic with witty dialogue');
  const [customCharacters, setCustomCharacters] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [milestoneIndex, setMilestoneIndex] = useState(0);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Cycling milestones during loading
  useEffect(() => {
    let interval: any;
    if (isGenerating) {
      setMilestoneIndex(0);
      interval = setInterval(() => {
        setMilestoneIndex((prev) => (prev + 1) % LOADING_MILESTONES.length);
      }, 2400);
    }
    return () => clearInterval(interval);
  }, [isGenerating]);

  if (!isOpen) return null;

  // Surprise Me Random Prompt
  const handleRandomize = () => {
    const random = INSPIRATION_PROMPTS[Math.floor(Math.random() * INSPIRATION_PROMPTS.length)];
    setConcept(random.concept);
    setGenre(random.genre);
    setArtStyle(random.artStyle);
    playComicSFX('CLICK');
  };

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!concept.trim()) {
      setErrorMsg('Please enter a comic concept or pick an inspiration prompt!');
      return;
    }

    setIsGenerating(true);
    setErrorMsg(null);
    playComicSFX('POW');

    try {
      const response = await fetch('/api/comic/generate-story', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          concept,
          genre,
          artStyle,
          panelCount,
          pacing,
          tone,
          customCharacters,
        }),
      });

      const data = await response.json();

      if (!data.success || !data.comic) {
        throw new Error(data.error || 'Failed to generate comic story');
      }

      const generated = data.comic;

      // Construct a valid full ComicBook object with unique IDs
      const fullComic: ComicBook = {
        id: `comic-${Date.now()}`,
        title: generated.title || 'Untitled Comic',
        issue: generated.issue || 'Issue #1',
        synopsis: generated.synopsis || concept,
        genre: genre,
        artStyle: artStyle,
        pacing: pacing,
        tone: tone,
        createdAt: new Date().toISOString(),
        pageLayout: panelCount === 6 ? 'classic_6' : 'grid_4',
        characters: (generated.characters || []).map((ch: any, idx: number) => ({
          id: `char-${Date.now()}-${idx}`,
          name: ch.name || `Character ${idx + 1}`,
          role: ch.role || 'protagonist',
          visualDescription: ch.visualDescription || '',
          signatureColor: ch.signatureColor || '#ef4444',
        })),
        panels: (generated.panels || []).map((p: any, idx: number) => ({
          id: `panel-${Date.now()}-${idx}`,
          panelNumber: idx + 1,
          cameraShot: p.cameraShot || 'medium_action',
          sceneDescription: p.sceneDescription || '',
          visualPrompt: p.visualPrompt || '',
          caption: p.caption || '',
          captionTheme: p.captionTheme || 'classic_yellow',
          captionPosition: 'top-left',
          speechBubbles: (p.speechBubbles || []).map((sb: any, sbIdx: number) => ({
            id: `sb-${Date.now()}-${idx}-${sbIdx}`,
            speaker: sb.speaker || 'Hero',
            text: sb.text || '',
            type: sb.type || 'speech',
            x: sb.x || 30 + (sbIdx * 20),
            y: sb.y || 25 + (sbIdx * 25),
            tailDirection: sb.tailDirection || (sbIdx % 2 === 0 ? 'bottom-left' : 'bottom-right'),
          })),
          soundEffects: (p.soundEffects || []).map((sfx: any, sfxIdx: number) => ({
            id: `sfx-${Date.now()}-${idx}-${sfxIdx}`,
            text: sfx.text || 'POW!',
            x: sfx.x || 65,
            y: sfx.y || 60,
            rotation: sfx.rotation || (sfxIdx % 2 === 0 ? 10 : -10),
            style: sfx.style || 'burst_yellow',
            size: sfx.size || 'lg',
          })),
        })),
      };

      // Play success confetti!
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#fde047', '#ef4444', '#3b82f6', '#000000'],
      });

      playComicSFX('KRAK-THOOM');
      onComicGenerated(fullComic);
      onClose();
    } catch (err: any) {
      console.error('Comic generation error:', err);
      setErrorMsg(err?.message || 'Gemini could not generate the comic. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-amber-50 border-4 border-black comic-shadow-xl p-5 sm:p-7 max-h-[90vh] overflow-y-auto my-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          disabled={isGenerating}
          className="absolute top-4 right-4 bg-white hover:bg-red-50 text-black border-2 border-black p-1.5 comic-shadow-sm cursor-pointer transition-transform active:translate-y-0.5"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Title */}
        <div className="mb-5 border-b-2 border-black pb-3">
          <div className="inline-block bg-black text-amber-400 font-mono text-[10px] px-2 py-0.5 uppercase tracking-widest font-bold mb-1">
            GEMINI 3.8 FLASH STORY STUDIO
          </div>
          <h2 className="font-comic-title text-3xl sm:text-4xl text-black tracking-wide leading-none">
            CREATE YOUR COMIC BOOK
          </h2>
          <p className="font-comic-body font-bold text-zinc-600 text-sm mt-1">
            Provide a storyline prompt or roll the dice. Gemini will generate characters, panels, camera angles, speech bubbles, and explosive SFX!
          </p>
        </div>

        {errorMsg && (
          <div className="mb-4 bg-red-100 border-2 border-red-600 text-red-900 p-3 text-xs font-bold font-mono">
            {errorMsg}
          </div>
        )}

        {/* Loading Overlay */}
        {isGenerating ? (
          <div className="py-12 px-4 flex flex-col items-center justify-center text-center">
            <div className="relative mb-6">
              <div className="w-20 h-20 bg-yellow-400 border-4 border-black comic-shadow-lg flex items-center justify-center -rotate-3 animate-bounce">
                <Sparkles className="w-10 h-10 text-red-600 animate-spin" />
              </div>
            </div>

            <h3 className="font-comic-title text-2xl sm:text-3xl text-black tracking-wider uppercase mb-2">
              CRAFTING YOUR COMIC ISSUE...
            </h3>
            <p className="text-sm font-mono font-bold text-amber-800 bg-amber-200 border-2 border-black px-4 py-1.5 comic-shadow-sm inline-block">
              {LOADING_MILESTONES[milestoneIndex]}
            </p>
            <p className="text-xs text-zinc-500 mt-4 max-w-md">
              Gemini 3.8 Flash is calculating narrative pacing, assigning camera angles, and balancing dialogue across all {panelCount} panels.
            </p>
          </div>
        ) : (
          <form onSubmit={handleGenerate} className="space-y-5">
            {/* Story Concept Input & Randomize */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="font-comic-title text-base text-black tracking-wide">
                  STORY CONCEPT / PLOT PROMPT
                </label>
                <button
                  type="button"
                  onClick={handleRandomize}
                  className="flex items-center gap-1.5 bg-yellow-300 hover:bg-yellow-400 text-black font-bold text-xs px-2.5 py-1 border-2 border-black comic-shadow-sm transition-transform active:translate-y-0.5 cursor-pointer uppercase"
                >
                  <Dices className="w-3.5 h-3.5 text-red-600" />
                  Surprise Me
                </button>
              </div>

              <textarea
                value={concept}
                onChange={(e) => setConcept(e.target.value)}
                placeholder="e.g. In 2099 Neo-Detroit, an underground mechanic discovers the engine of a crashed alien fighter and builds an unstoppable hover-suit..."
                rows={3}
                className="w-full bg-white border-2 border-black p-3 text-sm font-sans outline-none focus:ring-2 focus:ring-amber-400 resize-none font-medium placeholder:text-zinc-400"
              />

              {/* Inspiration Chips */}
              <div className="mt-2 flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
                <span className="text-zinc-500 font-bold uppercase text-[10px] shrink-0">Ideas:</span>
                {INSPIRATION_PROMPTS.slice(0, 3).map((insp, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => {
                      setConcept(insp.concept);
                      setGenre(insp.genre);
                      setArtStyle(insp.artStyle);
                    }}
                    className="bg-white hover:bg-amber-100 border border-black px-2 py-0.5 text-[11px] truncate max-w-[200px] shrink-0 font-medium cursor-pointer"
                  >
                    {insp.genre}: {insp.concept.slice(0, 30)}...
                  </button>
                ))}
              </div>
            </div>

            {/* Genre Selection */}
            <div>
              <label className="font-comic-title text-base text-black tracking-wide block mb-1.5">
                GENRE & THEME
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {GENRES.map((g) => {
                  const isSelected = genre === g.id;
                  return (
                    <button
                      key={g.id}
                      type="button"
                      onClick={() => setGenre(g.id)}
                      className={`p-2.5 text-left border-2 border-black transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-amber-300 comic-shadow font-bold'
                          : 'bg-white hover:bg-amber-50'
                      }`}
                    >
                      <div className="text-xl mb-1">{g.icon}</div>
                      <div className="text-xs font-bold leading-tight text-black">{g.label}</div>
                      <div className="text-[10px] text-zinc-500 leading-tight mt-0.5 line-clamp-1">
                        {g.desc}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Art Style & Panel Count */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="font-comic-title text-base text-black tracking-wide block mb-1">
                  ART & INKING STYLE
                </label>
                <select
                  value={artStyle}
                  onChange={(e) => setArtStyle(e.target.value as ArtStyle)}
                  className="w-full bg-white border-2 border-black p-2 text-xs font-bold outline-none cursor-pointer"
                >
                  {ART_STYLES.map((style) => (
                    <option key={style} value={style}>
                      {style}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="font-comic-title text-base text-black tracking-wide block mb-1">
                  PANEL COUNT & PAGE STRUCTURE
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[4, 6, 8].map((count) => (
                    <button
                      key={count}
                      type="button"
                      onClick={() => setPanelCount(count)}
                      className={`py-2 text-xs border-2 border-black font-bold uppercase transition-all cursor-pointer ${
                        panelCount === count
                          ? 'bg-amber-400 text-black comic-shadow-sm font-black'
                          : 'bg-white hover:bg-zinc-100 text-zinc-700'
                      }`}
                    >
                      {count} Panels
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Custom Characters / Tone */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="font-comic-title text-base text-black tracking-wide block mb-1">
                  CHARACTERS (OPTIONAL)
                </label>
                <input
                  type="text"
                  value={customCharacters}
                  onChange={(e) => setCustomCharacters(e.target.value)}
                  placeholder="e.g. Maya (cyborg pilot), Rex (laser dog)"
                  className="w-full bg-white border-2 border-black p-2 text-xs font-medium outline-none"
                />
              </div>

              <div>
                <label className="font-comic-title text-base text-black tracking-wide block mb-1">
                  PACING & DIALOGUE TONE
                </label>
                <select
                  value={tone}
                  onChange={(e) => setTone(e.target.value)}
                  className="w-full bg-white border-2 border-black p-2 text-xs font-bold outline-none cursor-pointer"
                >
                  <option value="Dramatic with witty dialogue">Dramatic with witty dialogue</option>
                  <option value="High-octane shonen action with explosive shouts">High-octane action with battle cries</option>
                  <option value="Gritty neo-noir monologue & cynical wit">Gritty neo-noir monologue & cynical wit</option>
                  <option value="Epic high fantasy lore & ancient prophecies">Epic high fantasy lore & prophecies</option>
                  <option value="Lighthearted, slapstick, and comedic">Lighthearted, slapstick, and comedic</option>
                </select>
              </div>
            </div>

            {/* Submit Button */}
            <div className="pt-3 border-t-2 border-black flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                className="bg-white hover:bg-zinc-100 text-black border-2 border-black font-bold text-xs px-4 py-2 uppercase tracking-wider cursor-pointer"
              >
                Cancel
              </button>

              <button
                type="submit"
                className="bg-red-600 hover:bg-red-500 text-white font-comic-title text-lg px-6 py-2 border-2 border-black comic-shadow transition-transform active:translate-y-0.5 flex items-center gap-2 cursor-pointer uppercase tracking-wider"
              >
                <Sparkles className="w-5 h-5 text-yellow-300 fill-yellow-300" />
                GENERATE COMIC WITH GEMINI
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
