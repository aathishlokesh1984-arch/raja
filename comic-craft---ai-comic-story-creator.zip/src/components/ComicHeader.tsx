import React from 'react';
import { 
  Sparkles, 
  BookOpen, 
  FileText, 
  Download, 
  Volume2, 
  VolumeX, 
  Library, 
  Plus, 
  Palette,
  Layers
} from 'lucide-react';
import { ComicBook } from '../types/comic';
import { playComicSFX } from '../utils/soundEffectsAudio';

interface ComicHeaderProps {
  currentComic: ComicBook;
  allComics: ComicBook[];
  onSelectComic: (comic: ComicBook) => void;
  onOpenGenerator: () => void;
  onOpenReader: () => void;
  onOpenScript: () => void;
  onOpenExport: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  viewMode: 'canvas' | 'script';
  setViewMode: (mode: 'canvas' | 'script') => void;
}

export const ComicHeader: React.FC<ComicHeaderProps> = ({
  currentComic,
  allComics,
  onSelectComic,
  onOpenGenerator,
  onOpenReader,
  onOpenExport,
  soundEnabled,
  onToggleSound,
  viewMode,
  setViewMode,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-amber-400 border-b-4 border-black shadow-[0_4px_0_#000]">
      {/* Top mini-bar: Gemini indicator & sound toggle */}
      <div className="bg-black text-amber-300 px-4 py-1 flex items-center justify-between text-xs font-mono">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1.5 font-bold tracking-wider uppercase">
            <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
            Gemini 3.8 Flash Comic Engine
          </span>
          <span className="text-zinc-500 hidden sm:inline">|</span>
          <span className="text-zinc-400 hidden sm:inline">
            Active: <strong className="text-zinc-200">{currentComic.title}</strong> ({currentComic.panels.length} Panels)
          </span>
        </div>

        <div className="flex items-center gap-4">
          <button
            onClick={() => {
              onToggleSound();
              if (!soundEnabled) playComicSFX('POW');
            }}
            className="flex items-center gap-1.5 text-xs text-amber-300 hover:text-white transition-colors cursor-pointer"
            title={soundEnabled ? 'Mute comic sound effects' : 'Enable comic sound effects'}
          >
            {soundEnabled ? (
              <>
                <Volume2 className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden sm:inline">SFX: ON</span>
              </>
            ) : (
              <>
                <VolumeX className="w-3.5 h-3.5 text-zinc-500" />
                <span className="hidden sm:inline text-zinc-400">SFX: OFF</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Comic Masthead */}
      <div className="max-w-7xl mx-auto px-4 py-2.5 flex flex-wrap items-center justify-between gap-3">
        {/* Logo / Brand */}
        <div className="flex items-center gap-3">
          <div className="bg-white border-2 border-black p-1.5 comic-shadow-sm -rotate-2">
            <span className="font-comic-title text-2xl sm:text-3xl text-red-600 leading-none tracking-wider">
              COMIC<span className="text-blue-600">CRAFT</span>
            </span>
          </div>

          {/* Comic Title & Selector */}
          <div className="flex items-center gap-2">
            <div className="relative group">
              <button 
                className="flex items-center gap-2 bg-amber-100 hover:bg-white text-black font-bold text-sm px-3 py-1.5 border-2 border-black comic-shadow-sm transition-all cursor-pointer"
                title="Switch Comics"
              >
                <Library className="w-4 h-4 text-zinc-700" />
                <span className="max-w-[140px] sm:max-w-[220px] truncate">{currentComic.title}</span>
                <span className="text-xs bg-amber-300 border border-black px-1.5 py-0.2 rounded font-mono">
                  {allComics.length}
                </span>
              </button>

              {/* Dropdown list */}
              <div className="absolute left-0 top-full mt-1.5 w-72 bg-white border-3 border-black comic-shadow-lg hidden group-hover:block hover:block z-50 p-2">
                <div className="text-xs font-bold uppercase tracking-wider text-zinc-500 px-2 py-1 border-b border-zinc-200">
                  Select Comic Book
                </div>
                <div className="max-h-60 overflow-y-auto space-y-1 mt-1">
                  {allComics.map((c) => (
                    <button
                      key={c.id}
                      onClick={() => {
                        onSelectComic(c);
                        playComicSFX('CLICK');
                      }}
                      className={`w-full text-left px-2.5 py-1.5 text-xs rounded transition-colors flex flex-col cursor-pointer ${
                        c.id === currentComic.id
                          ? 'bg-amber-200 border border-black font-bold'
                          : 'hover:bg-amber-50'
                      }`}
                    >
                      <span className="truncate">{c.title}</span>
                      <span className="text-[10px] text-zinc-500 flex items-center justify-between">
                        <span>{c.genre}</span>
                        <span>{c.panels.length} Panels</span>
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center flex-wrap gap-2">
          {/* Mode Switcher */}
          <div className="flex bg-black p-0.5 border-2 border-black">
            <button
              onClick={() => {
                setViewMode('canvas');
                playComicSFX('CLICK');
              }}
              className={`flex items-center gap-1.5 px-3 py-1 text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer ${
                viewMode === 'canvas'
                  ? 'bg-amber-300 text-black'
                  : 'text-amber-100 hover:text-white'
              }`}
            >
              <Palette className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Visual</span> Studio
            </button>
            <button
              onClick={() => {
                setViewMode('script');
                playComicSFX('CLICK');
              }}
              className={`flex items-center gap-1.5 px-3 py-1 text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer ${
                viewMode === 'script'
                  ? 'bg-amber-300 text-black'
                  : 'text-amber-100 hover:text-white'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              Script
            </button>
          </div>

          {/* Reader Mode Button */}
          <button
            onClick={() => {
              onOpenReader();
              playComicSFX('PAGE');
            }}
            className="flex items-center gap-1.5 bg-blue-500 hover:bg-blue-600 text-white font-bold text-xs px-3 py-1.5 border-2 border-black comic-shadow-sm transition-transform active:translate-y-0.5 cursor-pointer uppercase tracking-wider"
          >
            <BookOpen className="w-4 h-4" />
            <span className="hidden sm:inline">Read</span> Mode
          </button>

          {/* Export Button */}
          <button
            onClick={() => {
              onOpenExport();
              playComicSFX('CLICK');
            }}
            className="flex items-center gap-1.5 bg-white hover:bg-amber-50 text-black font-bold text-xs px-3 py-1.5 border-2 border-black comic-shadow-sm transition-transform active:translate-y-0.5 cursor-pointer uppercase tracking-wider"
          >
            <Download className="w-4 h-4 text-zinc-700" />
            Export
          </button>

          {/* New Comic CTA */}
          <button
            onClick={() => {
              onOpenGenerator();
              playComicSFX('POW');
            }}
            className="flex items-center gap-1.5 bg-red-500 hover:bg-red-600 text-white font-comic-title text-base px-4 py-1 border-2 border-black comic-shadow-sm transition-transform active:translate-y-0.5 hover:rotate-1 cursor-pointer tracking-wider"
          >
            <Sparkles className="w-4 h-4 text-yellow-300 fill-yellow-300" />
            + CREATE COMIC
          </button>
        </div>
      </div>
    </header>
  );
};
