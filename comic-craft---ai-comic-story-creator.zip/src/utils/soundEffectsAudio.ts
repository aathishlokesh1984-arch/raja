// Web Audio API Retro Comic Sound FX Synthesizer

let audioCtx: AudioContext | null = null;
let soundEnabled = true;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

export function setSoundFXEnabled(enabled: boolean) {
  soundEnabled = enabled;
}

export function isSoundFXEnabled(): boolean {
  return soundEnabled;
}

export function playComicSFX(effectName: string = 'POW') {
  if (!soundEnabled) return;
  const ctx = getAudioContext();
  if (!ctx) return;

  const upper = effectName.toUpperCase();

  try {
    const now = ctx.currentTime;

    if (upper.includes('POW') || upper.includes('BAM') || upper.includes('WHAM')) {
      // Punch impact: Low pitch drop + punchy oscillator
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(260, now);
      osc.frequency.exponentialRampToValueAtTime(45, now + 0.16);

      gain.gain.setValueAtTime(0.7, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.18);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.2);

      // Noise pop
      createNoiseBuffer(ctx, now, 0.08, 0.4);
    } else if (upper.includes('ZAP') || upper.includes('BZZT') || upper.includes('LASER')) {
      // Sci-fi laser blast: fast down sweep with distortion
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(1400, now);
      osc.frequency.exponentialRampToValueAtTime(120, now + 0.22);

      gain.gain.setValueAtTime(0.5, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.25);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.25);
    } else if (upper.includes('KRAK') || upper.includes('THOOM') || upper.includes('BOOM')) {
      // Thunder / Explosion: Low boom with prolonged noise
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(120, now);
      osc.frequency.exponentialRampToValueAtTime(30, now + 0.45);

      gain.gain.setValueAtTime(0.8, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.5);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.5);

      createNoiseBuffer(ctx, now, 0.35, 0.5);
    } else if (upper.includes('WHOOSH') || upper.includes('SWOOSH')) {
      // Wind whoosh: filtered noise sweep
      createNoiseBuffer(ctx, now, 0.25, 0.4, true);
    } else if (upper.includes('CLICK') || upper.includes('PAGE')) {
      // Page flip / button click: quick bright tick
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(800, now);
      osc.frequency.exponentialRampToValueAtTime(300, now + 0.04);

      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.05);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.05);
    } else {
      // Default comic chime
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.12);

      gain.gain.setValueAtTime(0.4, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.16);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.18);
    }
  } catch (e) {
    console.debug('Audio play prevented or unavailable:', e);
  }
}

function createNoiseBuffer(ctx: AudioContext, startTime: number, duration: number, volume: number, filterSweep = false) {
  const bufferSize = ctx.sampleRate * duration;
  const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
  const data = buffer.getChannelData(0);

  for (let i = 0; i < bufferSize; i++) {
    data[i] = Math.random() * 2 - 1;
  }

  const noise = ctx.createBufferSource();
  noise.buffer = buffer;

  const gain = ctx.createGain();
  gain.gain.setValueAtTime(volume, startTime);
  gain.gain.exponentialRampToValueAtTime(0.01, startTime + duration);

  if (filterSweep) {
    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(300, startTime);
    filter.frequency.exponentialRampToValueAtTime(1800, startTime + duration * 0.6);
    filter.frequency.exponentialRampToValueAtTime(400, startTime + duration);
    noise.connect(filter);
    filter.connect(gain);
  } else {
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(800, startTime);
    filter.frequency.exponentialRampToValueAtTime(200, startTime + duration);
    noise.connect(filter);
    filter.connect(gain);
  }

  gain.connect(ctx.destination);
  noise.start(startTime);
  noise.stop(startTime + duration);
}
