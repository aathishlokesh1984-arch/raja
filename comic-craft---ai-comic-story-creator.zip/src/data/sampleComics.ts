import { ComicBook } from '../types/comic';

export const SAMPLE_COMICS: ComicBook[] = [
  {
    id: 'comic-neon-vigilante',
    title: 'The Neon Vigilante',
    issue: 'Issue #1: Shadows of Neo-Metropolis',
    synopsis: 'In a rain-drenched cyberpunk megalopolis, rogue cyber-detective Jax Mercer investigates a vanished AI core while staying one step ahead of the Megacorp hit squads.',
    genre: 'Cyberpunk Noir',
    artStyle: 'Cyberpunk Neon & Heavy Shadows',
    pacing: 'cinematic',
    tone: 'Gritty, dramatic with sharp cynical wit',
    createdAt: '2026-09-30T00:00:00.000Z',
    pageLayout: 'grid_4',
    characters: [
      {
        id: 'char-1',
        name: 'Jax Mercer',
        role: 'protagonist',
        visualDescription: 'Cybernetic right eye glowing cyan, worn trench coat with illuminated collar, dual neural shock blasters.',
        signatureColor: '#06b6d4',
      },
      {
        id: 'char-2',
        name: 'Cipher-9',
        role: 'sidekick',
        visualDescription: 'Rogue holographic AI companion projecting as a flickering geometric silhouette.',
        signatureColor: '#ec4899',
      },
      {
        id: 'char-3',
        name: 'Director Vance',
        role: 'antagonist',
        visualDescription: 'Titanium-suited corporate enforcer with polished obsidian mask.',
        signatureColor: '#e11d48',
      },
    ],
    panels: [
      {
        id: 'panel-1',
        panelNumber: 1,
        cameraShot: 'wide_establishing',
        sceneDescription: 'Jax stands in an acid-rain slicked alleyway between towering holographic neon billboards, scanning for an encryption trail.',
        visualPrompt: 'Cyberpunk noir alleyway with neon signs, puddles reflecting magenta and cyan light, cyber detective in long trench coat',
        caption: 'Neo-Metropolis, Sector 4. The rain washes away everything except blood and bad decisions.',
        captionPosition: 'top-left',
        captionTheme: 'dark_noir',
        imageUrl: '/src/assets/images/cyberpunk_detective_1790757079769.jpg',
        imageType: 'asset',
        speechBubbles: [
          {
            id: 'sb-1',
            speaker: 'Jax',
            text: 'Cipher, tell me you have a lock on that frequency.',
            type: 'speech',
            x: 22,
            y: 52,
            tailDirection: 'bottom-left',
          },
          {
            id: 'sb-2',
            speaker: 'Cipher-9',
            text: 'Signal is decaying, Jax. They know we are listening!',
            type: 'radio',
            x: 58,
            y: 28,
            tailDirection: 'bottom-right',
          },
        ],
        soundEffects: [
          {
            id: 'sfx-1',
            text: 'DRIP... DRIP...',
            x: 12,
            y: 80,
            rotation: -5,
            style: 'neon_cyan',
            size: 'sm',
          },
        ],
        borderStyle: 'classic_black',
      },
      {
        id: 'panel-2',
        panelNumber: 2,
        cameraShot: 'low_angle_hero',
        sceneDescription: 'Jax leaps across high-altitude skyscraper bridges as an emergency siren blares across the skyline.',
        visualPrompt: 'Masked hero leaping across neon city skyline, dynamic perspective, dramatic inking and Ben-Day dots',
        caption: 'No elevator goes where I need to be. Good thing I never take the stairs.',
        captionPosition: 'top-left',
        captionTheme: 'classic_yellow',
        imageUrl: '/src/assets/images/comic_hero_cover_1790757065491.jpg',
        imageType: 'asset',
        speechBubbles: [
          {
            id: 'sb-3',
            speaker: 'Jax',
            text: 'Brace for deceleration!',
            type: 'shout',
            x: 52,
            y: 22,
            tailDirection: 'bottom-left',
          },
        ],
        soundEffects: [
          {
            id: 'sfx-2',
            text: 'WHOOSH!',
            x: 65,
            y: 65,
            rotation: 12,
            style: 'burst_yellow',
            size: 'lg',
          },
        ],
        borderStyle: 'classic_black',
      },
      {
        id: 'panel-3',
        panelNumber: 3,
        cameraShot: 'dutch_angle',
        sceneDescription: 'Corporate drones corner Jax at the server nexus, opening fire with glowing laser charges.',
        visualPrompt: 'High tech computer server room, laser blast firefight, sparks flying, high contrast comic action',
        caption: 'Vance sent his private squad. Flattering, but expensive.',
        captionPosition: 'top-left',
        captionTheme: 'dark_noir',
        svgArt: `<svg viewBox="0 0 800 600" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <radialGradient id="blastGlow" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#fef08a" />
      <stop offset="40%" stop-color="#ef4444" />
      <stop offset="100%" stop-color="#0f172a" />
    </radialGradient>
    <pattern id="halftone3" width="10" height="10" patternUnits="userSpaceOnUse">
      <circle cx="5" cy="5" r="2" fill="#000" opacity="0.25" />
    </pattern>
  </defs>
  <rect width="800" height="600" fill="#090d16" />
  <rect width="800" height="600" fill="url(#halftone3)" />
  <!-- Server stacks -->
  <rect x="40" y="80" width="140" height="480" fill="#1e293b" stroke="#000" stroke-width="4" />
  <rect x="620" y="80" width="140" height="480" fill="#1e293b" stroke="#000" stroke-width="4" />
  <!-- Server lights -->
  <line x1="70" y1="120" x2="150" y2="120" stroke="#06b6d4" stroke-width="6" stroke-dasharray="10 8" />
  <line x1="70" y1="160" x2="150" y2="160" stroke="#ec4899" stroke-width="6" stroke-dasharray="12 6" />
  <line x1="650" y1="140" x2="730" y2="140" stroke="#ef4444" stroke-width="6" stroke-dasharray="14 8" />
  <!-- Laser blast beam -->
  <line x1="120" y1="280" x2="680" y2="340" stroke="#f43f5e" stroke-width="16" stroke-linecap="round" />
  <line x1="120" y1="280" x2="680" y2="340" stroke="#fff" stroke-width="6" stroke-linecap="round" />
  <!-- Blast burst center -->
  <circle cx="480" cy="320" r="100" fill="url(#blastGlow)" opacity="0.85" />
  <!-- Hero Silhouette ducking -->
  <path d="M 280 500 Q 320 380 380 390 Q 420 360 460 400 L 480 530 L 260 540 Z" fill="#020617" stroke="#000" stroke-width="5" />
  <!-- Gun barrel glow -->
  <circle cx="460" cy="380" r="12" fill="#38bdf8" />
</svg>`,
        imageType: 'svg_vector',
        speechBubbles: [
          {
            id: 'sb-4',
            speaker: 'Drone Squad',
            text: 'TARGET ACQUIRED! SURRENDER THE DRIVE!',
            type: 'shout',
            x: 52,
            y: 20,
            tailDirection: 'bottom-right',
          },
        ],
        soundEffects: [
          {
            id: 'sfx-3',
            text: 'ZAP-ZAP-ZAP!',
            x: 25,
            y: 42,
            rotation: -14,
            style: 'shock_red',
            size: 'md',
          },
        ],
        borderStyle: 'classic_black',
      },
      {
        id: 'panel-4',
        panelNumber: 4,
        cameraShot: 'close_up',
        sceneDescription: 'Jax plugs the decrypted data drive into his wrist terminal, a smirk spreading across his face as the Megacorp firewalls collapse.',
        visualPrompt: 'Extreme close up of cybernetic detective smiling, cybernetic eye blazing with binary codes, neon rain on collar',
        caption: 'They thought they owned the city. Tonight, the city gets its receipt.',
        captionPosition: 'bottom-left',
        captionTheme: 'classic_yellow',
        svgArt: `<svg viewBox="0 0 800 600" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <radialGradient id="cyberEye" cx="60%" cy="40%" r="40%">
      <stop offset="0%" stop-color="#e0f2fe" />
      <stop offset="50%" stop-color="#0284c7" />
      <stop offset="100%" stop-color="#082f49" />
    </radialGradient>
  </defs>
  <rect width="800" height="600" fill="#0f172a" />
  <!-- Speed lines radiating from eye -->
  <g stroke="#0284c7" stroke-width="2" opacity="0.3">
    <line x1="480" y1="260" x2="0" y2="0" />
    <line x1="480" y1="260" x2="800" y2="0" />
    <line x1="480" y1="260" x2="0" y2="600" />
    <line x1="480" y1="260" x2="800" y2="600" />
    <line x1="480" y1="260" x2="480" y2="0" />
    <line x1="480" y1="260" x2="0" y2="260" />
  </g>
  <!-- Face silhouette & dramatic shadows -->
  <path d="M 220 120 C 320 80 440 80 540 120 C 620 180 640 380 580 500 C 500 580 300 580 240 500 C 180 380 200 180 220 120 Z" fill="#f8fafc" stroke="#000" stroke-width="6" />
  <!-- Deep ink comic shadow half face -->
  <path d="M 220 120 C 300 160 320 320 310 540 C 260 530 240 500 240 500 C 180 380 200 180 220 120 Z" fill="#090d16" />
  <!-- Cyber Eye glowing -->
  <circle cx="480" cy="260" r="32" fill="url(#cyberEye)" stroke="#38bdf8" stroke-width="5" />
  <circle cx="480" cy="260" r="12" fill="#fff" />
  <!-- Trench coat collar -->
  <path d="M 120 480 L 300 420 L 400 590 L 100 600 Z" fill="#334155" stroke="#000" stroke-width="5" />
  <path d="M 680 480 L 500 420 L 400 590 L 700 600 Z" fill="#1e293b" stroke="#000" stroke-width="5" />
</svg>`,
        imageType: 'svg_vector',
        speechBubbles: [
          {
            id: 'sb-5',
            speaker: 'Jax',
            text: 'System override complete. Welcome to the free world, Vance.',
            type: 'speech',
            x: 28,
            y: 68,
            tailDirection: 'top-left',
          },
        ],
        soundEffects: [
          {
            id: 'sfx-4',
            text: 'CLICK!',
            x: 72,
            y: 48,
            rotation: 8,
            style: 'burst_yellow',
            size: 'md',
          },
        ],
        borderStyle: 'classic_black',
      },
    ],
  },
  {
    id: 'comic-starforged-fantasy',
    title: 'Chronicles of the Starforged',
    issue: 'Chapter 7: The Colossus Awakes',
    synopsis: 'Deep within the Shattered Crags, Sorceress Cheryl and her companion awaken an ancient celestial guardian that holds the key to mending the broken firmament.',
    genre: 'Epic Fantasy',
    artStyle: 'Modern Comic (Bold Inks & Halftone)',
    pacing: 'action-packed',
    tone: 'Grand, mystical, and heroic',
    createdAt: '2026-09-30T00:00:00.000Z',
    pageLayout: 'grid_4',
    characters: [
      {
        id: 'char-sf-1',
        name: 'Cheryl Sunstrider',
        role: 'protagonist',
        visualDescription: 'Braided silver hair, flowing starry mantle, dual lightning staves.',
        signatureColor: '#a855f7',
      },
      {
        id: 'char-sf-2',
        name: 'The Stone Colossus',
        role: 'mentor',
        visualDescription: 'Titan of carved obsidian and glowing runic glyphs slumbering in mountain roots.',
        signatureColor: '#eab308',
      },
    ],
    panels: [
      {
        id: 'panel-sf-1',
        panelNumber: 1,
        cameraShot: 'wide_establishing',
        sceneDescription: 'Cheryl channels crackling lightning spells against the towering ancient stone colossus as the runes ignite.',
        visualPrompt: 'Epic fantasy comic panel, sorceress conjuring lightning orbs against a towering stone colossus, dynamic angles, vibrant comic art',
        caption: 'The ancient prophecy was clear: Only lightning born of mortal heart could stir the Mountain King.',
        captionPosition: 'top-left',
        captionTheme: 'classic_yellow',
        imageUrl: '/src/assets/images/fantasy_mage_dragon_1790757093466.jpg',
        imageType: 'asset',
        speechBubbles: [
          {
            id: 'sb-sf-1',
            speaker: 'Cheryl',
            text: 'By the Star of Ardyn... HEAR MY CALL!',
            type: 'shout',
            x: 35,
            y: 28,
            tailDirection: 'bottom-left',
          },
        ],
        soundEffects: [
          {
            id: 'sfx-sf-1',
            text: 'KRAK-THOOM!',
            x: 60,
            y: 50,
            rotation: -10,
            style: 'burst_yellow',
            size: 'xl',
          },
        ],
        borderStyle: 'classic_black',
      },
      {
        id: 'panel-sf-2',
        panelNumber: 2,
        cameraShot: 'close_up',
        sceneDescription: 'The Colossus slowly opens its molten gold eyes, dust tumbling from centuries of slumber.',
        visualPrompt: 'Runic stone titan face with glowing gold eyes opening, glowing magma cracks, dust clouds falling',
        caption: 'Ten thousand years of silence, shattered in a single heartbeat.',
        captionPosition: 'top-left',
        captionTheme: 'dark_noir',
        svgArt: `<svg viewBox="0 0 800 600" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <radialGradient id="titanGlow" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#fef08a" />
      <stop offset="60%" stop-color="#ca8a04" />
      <stop offset="100%" stop-color="#451a03" />
    </radialGradient>
  </defs>
  <rect width="800" height="600" fill="#1c1917" />
  <!-- Mountain Crags -->
  <path d="M 0 600 L 220 200 L 400 350 L 600 150 L 800 600 Z" fill="#292524" stroke="#000" stroke-width="6" />
  <!-- Giant Eyes -->
  <ellipse cx="280" cy="300" rx="65" ry="32" fill="url(#titanGlow)" stroke="#facc15" stroke-width="6" />
  <ellipse cx="520" cy="300" rx="65" ry="32" fill="url(#titanGlow)" stroke="#facc15" stroke-width="6" />
  <!-- Cracking energy lines -->
  <path d="M 280 332 L 250 480 L 190 580" stroke="#facc15" stroke-width="5" fill="none" />
  <path d="M 520 332 L 560 460 L 640 590" stroke="#facc15" stroke-width="5" fill="none" />
</svg>`,
        imageType: 'svg_vector',
        speechBubbles: [
          {
            id: 'sb-sf-2',
            speaker: 'Colossus',
            text: 'WHO DARES DISTURB THE ROOTS OF THE SKY...?',
            type: 'shout',
            x: 48,
            y: 65,
            tailDirection: 'top-right',
          },
        ],
        soundEffects: [
          {
            id: 'sfx-sf-2',
            text: 'RUUUUMBLE!',
            x: 18,
            y: 42,
            rotation: 5,
            style: 'burst_yellow',
            size: 'lg',
          },
        ],
        borderStyle: 'classic_black',
      },
    ],
  },
  {
    id: 'comic-kage-manga',
    title: 'Kage: Spirit Blade Unleashed',
    issue: 'Episode 14: The Final Form',
    synopsis: 'Surrounded on the rooftop of Neo-Kyoto by demonic shadows, young swordsman Ren taps into his ancestral spirit flame to execute the forbidden Ten-Strike Whirlwind.',
    genre: 'Shonen Manga',
    artStyle: 'Action Shonen Manga (Screentone)',
    pacing: 'fast-action',
    tone: 'Fiery, breathless, high-stakes battle',
    createdAt: '2026-09-30T00:00:00.000Z',
    pageLayout: 'grid_4',
    characters: [
      {
        id: 'char-manga-1',
        name: 'Ren Kageyama',
        role: 'protagonist',
        visualDescription: 'Spiky jet-black hair with white tips, crimson haori jacket, dual celestial katanas.',
        signatureColor: '#ef4444',
      },
    ],
    panels: [
      {
        id: 'panel-m-1',
        panelNumber: 1,
        cameraShot: 'low_angle_hero',
        sceneDescription: 'Ren gathers raw spirit aura into his fist and blade, speed lines distorting the air around him.',
        visualPrompt: 'Dynamic shonen manga comic panel, fierce anime hero preparing energy blast attack, dramatic ink speed lines, halftone dot screening',
        caption: 'Fear is just an illusion. Focus the spirit. Release the storm.',
        captionPosition: 'top-left',
        captionTheme: 'manga_white',
        imageUrl: '/src/assets/images/manga_warrior_panel_1790757106015.jpg',
        imageType: 'asset',
        speechBubbles: [
          {
            id: 'sb-m-1',
            speaker: 'Ren',
            text: 'I will NOT let this city fall!',
            type: 'shout',
            x: 48,
            y: 22,
            tailDirection: 'bottom-left',
          },
        ],
        soundEffects: [
          {
            id: 'sfx-m-1',
            text: 'SHHH-WAAA!',
            x: 65,
            y: 60,
            rotation: -15,
            style: 'speed_white',
            size: 'lg',
          },
        ],
        borderStyle: 'classic_black',
      },
      {
        id: 'panel-m-2',
        panelNumber: 2,
        cameraShot: 'extreme_close_up',
        sceneDescription: 'Ren strikes in a blinding fraction of a second, the blade slicing through the demon veil.',
        visualPrompt: 'Horizontal slash of celestial white blade against pitch black ink shadows, dramatic manga action cut',
        caption: 'First stance: Celestial Dawn.',
        captionPosition: 'bottom-left',
        captionTheme: 'manga_white',
        svgArt: `<svg viewBox="0 0 800 600" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
  <rect width="800" height="600" fill="#000" />
  <!-- Diagonal slice flash -->
  <polygon points="0,520 800,80 800,140 0,580" fill="#ffffff" />
  <!-- Speed lines in ink -->
  <line x1="50" y1="560" x2="750" y2="120" stroke="#f43f5e" stroke-width="4" />
  <line x1="0" y1="300" x2="800" y2="300" stroke="#fff" stroke-width="2" stroke-dasharray="20 15" opacity="0.4" />
  <!-- Character eye focus cut -->
  <rect x="250" y="240" width="300" height="120" fill="#18181b" stroke="#fff" stroke-width="4" />
  <ellipse cx="400" cy="300" rx="35" ry="18" fill="#ef4444" />
  <circle cx="400" cy="300" r="8" fill="#fff" />
</svg>`,
        imageType: 'svg_vector',
        speechBubbles: [
          {
            id: 'sb-m-2',
            speaker: 'Ren',
            text: 'SLASH!',
            type: 'shout',
            x: 60,
            y: 40,
            tailDirection: 'bottom-right',
          },
        ],
        soundEffects: [
          {
            id: 'sfx-m-2',
            text: 'BAM!',
            x: 20,
            y: 25,
            rotation: 14,
            style: 'shock_red',
            size: 'xl',
          },
        ],
        borderStyle: 'classic_black',
      },
    ],
  },
];
