export type Genre =
  | 'Superhero Modern'
  | 'Cyberpunk Noir'
  | 'Shonen Manga'
  | 'Epic Fantasy'
  | 'Sci-Fi Mystery'
  | 'Retro Pop-Art 1960s'
  | 'Horror & Supernatural'
  | 'Cozy Comic Strip';

export type ArtStyle =
  | 'Modern Comic (Bold Inks & Halftone)'
  | 'Vintage Pop-Art (Ben-Day Dots)'
  | 'Cyberpunk Neon & Heavy Shadows'
  | 'Action Shonen Manga (Screentone)'
  | 'Dark Graphic Novel (Noir Contrast)'
  | 'Vibrant European Bande Dessinée';

export type BubbleType = 'speech' | 'shout' | 'thought' | 'whisper' | 'radio';

export type SoundEffectStyle =
  | 'burst_yellow'
  | 'shock_red'
  | 'neon_cyan'
  | 'dark_purple'
  | 'speed_white';

export interface SpeechBubble {
  id: string;
  speaker: string;
  text: string;
  type: BubbleType;
  x: number; // 0 to 100 percentage
  y: number; // 0 to 100 percentage
  tailDirection?: 'bottom-left' | 'bottom-right' | 'top-left' | 'top-right' | 'none';
}

export interface SoundEffect {
  id: string;
  text: string;
  x: number; // 0 to 100 percentage
  y: number; // 0 to 100 percentage
  rotation?: number; // degrees
  style: SoundEffectStyle;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

export interface ComicPanel {
  id: string;
  panelNumber: number;
  cameraShot:
    | 'wide_establishing'
    | 'medium_action'
    | 'close_up'
    | 'extreme_close_up'
    | 'dutch_angle'
    | 'low_angle_hero'
    | 'birds_eye';
  sceneDescription: string;
  visualPrompt: string;
  caption?: string;
  captionPosition?: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right';
  captionTheme?: 'classic_yellow' | 'dark_noir' | 'scifi_cyan' | 'manga_white';
  imageUrl?: string;
  svgArt?: string; // Direct inline SVG vector artwork
  imageType?: 'asset' | 'ai_generated' | 'svg_vector' | 'placeholder';
  speechBubbles: SpeechBubble[];
  soundEffects: SoundEffect[];
  borderStyle?: 'classic_black' | 'rough_ink' | 'borderless' | 'neon_glow';
  aspectRatio?: '1:1' | '4:3' | '16:9' | '3:4';
  isGeneratingArt?: boolean;
}

export interface ComicCharacter {
  id: string;
  name: string;
  role: 'protagonist' | 'antagonist' | 'sidekick' | 'mentor' | 'supporting';
  visualDescription: string;
  signatureColor: string;
}

export interface ComicBook {
  id: string;
  title: string;
  issue: string;
  synopsis: string;
  genre: Genre;
  artStyle: ArtStyle;
  pacing: string;
  tone: string;
  characters: ComicCharacter[];
  panels: ComicPanel[];
  createdAt: string;
  author?: string;
  pageLayout?: 'grid_4' | 'classic_6' | 'dynamic_5' | 'strip_3' | 'webtoon_vertical';
}
