import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3000;

app.use(express.json({ limit: '10mb' }));

// Initialize Google Gemini API Client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    hasApiKey: Boolean(process.env.GEMINI_API_KEY),
    time: new Date().toISOString(),
  });
});

// 1. Generate Complete Multi-Panel Comic Story
app.post('/api/comic/generate-story', async (req, res) => {
  try {
    const {
      concept = 'A futuristic hero facing an impossible dilemma',
      genre = 'Cyberpunk Superhero',
      artStyle = 'Modern Comic (Bold Inks & Halftone)',
      panelCount = 4,
      pacing = 'action-packed',
      tone = 'Dramatic with witty moments',
      customCharacters = '',
    } = req.body;

    const systemPrompt = `You are a legendary comic book writer and graphic novel artist director (Marvel, DC, Image Comics, Shonen Jump style).
You specialize in writing visually dynamic, cinematic, and narratively gripping comic stories broken down panel-by-panel.

Write a complete comic issue/strip with exactly ${panelCount} panels.
Ensure high narrative tension, distinct character voices, snappy dialogue balloons, cinematic camera angles, classic narration caption boxes, and punchy onomatopoeia sound effects (e.g., KRAK-THOOM!, SKRRRRT!, POW!, BZZZT!).
Provide evocative visual prompts for comic illustrators describing character poses, lighting, inking, and background scenery.`;

    const prompt = `Genre: ${genre}
Art Style: ${artStyle}
Pacing: ${pacing}
Tone: ${tone}
${customCharacters ? `Characters requested: ${customCharacters}` : ''}
Story Concept / Prompt: ${concept}

Generate the structured comic book data with exactly ${panelCount} panels.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.85,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING, description: 'Catchy comic title' },
            issue: { type: Type.STRING, description: 'Issue or Episode title (e.g. Issue #1: Neon Reckoning)' },
            synopsis: { type: Type.STRING, description: '2-3 sentence overview of the comic plot' },
            genre: { type: Type.STRING },
            artStyle: { type: Type.STRING },
            characters: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  role: { type: Type.STRING, description: 'protagonist, antagonist, sidekick, or mentor' },
                  visualDescription: { type: Type.STRING, description: 'Appearance, costume, hairstyle, signature features' },
                  signatureColor: { type: Type.STRING, description: 'Hex code or color name for theme' },
                },
                required: ['name', 'role', 'visualDescription', 'signatureColor'],
              },
            },
            panels: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  panelNumber: { type: Type.INTEGER },
                  cameraShot: {
                    type: Type.STRING,
                    description: 'wide_establishing, medium_action, close_up, extreme_close_up, dutch_angle, low_angle_hero, or birds_eye',
                  },
                  sceneDescription: { type: Type.STRING, description: 'What is happening in this specific comic panel' },
                  visualPrompt: { type: Type.STRING, description: 'Detailed prompt for comic illustrator: lighting, pose, background, inks' },
                  caption: { type: Type.STRING, description: 'Narrator caption box text (or empty if none)' },
                  captionTheme: { type: Type.STRING, description: 'classic_yellow, dark_noir, scifi_cyan, or manga_white' },
                  speechBubbles: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        speaker: { type: Type.STRING },
                        text: { type: Type.STRING },
                        type: { type: Type.STRING, description: 'speech, shout, thought, or whisper' },
                        x: { type: Type.NUMBER, description: 'Percentage from left 10 to 80' },
                        y: { type: Type.NUMBER, description: 'Percentage from top 10 to 75' },
                        tailDirection: { type: Type.STRING, description: 'bottom-left, bottom-right, top-left, or top-right' },
                      },
                      required: ['speaker', 'text', 'type'],
                    },
                  },
                  soundEffects: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        text: { type: Type.STRING, description: 'e.g. POW!, KRAK-THOOM!, BZZT!, SKRRRT!' },
                        x: { type: Type.NUMBER, description: 'Percentage 10 to 80' },
                        y: { type: Type.NUMBER, description: 'Percentage 10 to 80' },
                        rotation: { type: Type.NUMBER, description: 'Angle in degrees between -20 and 20' },
                        style: { type: Type.STRING, description: 'burst_yellow, shock_red, neon_cyan, dark_purple, or speed_white' },
                        size: { type: Type.STRING, description: 'sm, md, lg, or xl' },
                      },
                      required: ['text', 'style'],
                    },
                  },
                },
                required: ['panelNumber', 'cameraShot', 'sceneDescription', 'visualPrompt', 'speechBubbles', 'soundEffects'],
              },
            },
          },
          required: ['title', 'issue', 'synopsis', 'characters', 'panels'],
        },
      },
    });

    const text = response.text?.trim() || '{}';
    const parsedData = JSON.parse(text);

    res.json({
      success: true,
      comic: parsedData,
    });
  } catch (error: any) {
    console.error('Error generating comic story:', error);
    res.status(500).json({
      success: false,
      error: error?.message || 'Failed to generate comic story',
    });
  }
});

// 2. Generate Stylized Vector SVG Comic Panel Artwork
app.post('/api/comic/generate-svg-art', async (req, res) => {
  try {
    const { visualPrompt, sceneDescription, artStyle = 'Modern Comic', genre = 'Superhero', panelNumber = 1 } = req.body;

    const systemPrompt = `You are a master digital comic book illustrator and SVG graphics artist.
Create a complete, visually striking, resolution-independent SVG comic panel artwork.
Return ONLY valid raw SVG markup starting with <svg and ending with </svg>. No markdown formatting, no backticks, no comments outside the svg.
The SVG MUST:
1. Have viewBox="0 0 800 600" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg"
2. Feature rich visual depth: background gradients/cityscapes/horizons, midground silhouettes or detailed objects, foreground dramatic character figures with strong graphic ink lines (stroke="#000" stroke-width="3" or "4").
3. Include dynamic comic book elements: dramatic speed lines (radial or directional strokes), lighting contrast, halftone dot patterns (using <pattern>), dramatic highlights, shadows, and expressive colors matching the genre (${genre}).
4. Ensure all SVG tags are properly closed and valid XML.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `Generate an SVG comic illustration for Panel #${panelNumber}:
Scene: ${sceneDescription}
Visual details: ${visualPrompt}
Art Style: ${artStyle}
Genre: ${genre}`,
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.8,
      },
    });

    let rawSvg = response.text || '';
    // Clean markdown codeblocks if model included them
    rawSvg = rawSvg.replace(/```xml/gi, '').replace(/```svg/gi, '').replace(/```/gi, '').trim();

    const svgStart = rawSvg.indexOf('<svg');
    const svgEnd = rawSvg.lastIndexOf('</svg>');

    if (svgStart !== -1 && svgEnd !== -1) {
      rawSvg = rawSvg.substring(svgStart, svgEnd + 6);
    } else {
      throw new Error('Valid SVG structure not found in response');
    }

    res.json({
      success: true,
      svg: rawSvg,
    });
  } catch (error: any) {
    console.error('Error generating SVG comic art:', error);
    res.status(500).json({
      success: false,
      error: error?.message || 'Failed to generate vector comic art',
    });
  }
});

// 3. Generate AI Image for Panel
app.post('/api/comic/generate-image', async (req, res) => {
  try {
    const { prompt, aspectRatio = '4:3', artStyle = 'comic book illustration' } = req.body;

    const fullPrompt = `${prompt}, ${artStyle}, high contrast ink lines, professional comic book graphic novel art style, dynamic lighting, masterpiece, clean composition`;

    // Attempt Gemini Flash Image Generation
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.1-flash-lite-image',
        contents: {
          parts: [{ text: fullPrompt }],
        },
        config: {
          imageConfig: {
            aspectRatio: aspectRatio as any,
          },
        },
      });

      let imageUrl = null;
      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData?.data) {
            imageUrl = `data:image/png;base64,${part.inlineData.data}`;
            break;
          }
        }
      }

      if (imageUrl) {
        return res.json({
          success: true,
          imageUrl,
          engine: 'gemini-3.1-flash-lite-image',
        });
      }
    } catch (imageErr: any) {
      console.warn('Image generation model not available or quota exceeded, will offer vector art fallback:', imageErr?.message);
    }

    // Return fallback guidance so frontend can switch to Vector SVG generation or styled artwork
    res.json({
      success: false,
      fallbackToVector: true,
      message: 'Gemini flash-lite-image was not available; use Vector Comic Art Engine or pre-generated art.',
    });
  } catch (error: any) {
    console.error('Error in generate-image endpoint:', error);
    res.status(500).json({
      success: false,
      error: error?.message || 'Image generation failed',
    });
  }
});

// 4. Refine / Rewrite Panel Dialog, Sound FX, or Visuals
app.post('/api/comic/refine-panel', async (req, res) => {
  try {
    const { panel, instruction, genre } = req.body;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `We have this comic panel:
${JSON.stringify(panel, null, 2)}

User refinement request: "${instruction}"
Genre: ${genre}

Rewrite the panel according to the user request. Keep panelNumber the same. Return updated JSON object matching panel structure.`,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            caption: { type: Type.STRING },
            captionTheme: { type: Type.STRING },
            sceneDescription: { type: Type.STRING },
            visualPrompt: { type: Type.STRING },
            speechBubbles: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  speaker: { type: Type.STRING },
                  text: { type: Type.STRING },
                  type: { type: Type.STRING },
                  x: { type: Type.NUMBER },
                  y: { type: Type.NUMBER },
                  tailDirection: { type: Type.STRING },
                },
                required: ['speaker', 'text', 'type'],
              },
            },
            soundEffects: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  text: { type: Type.STRING },
                  x: { type: Type.NUMBER },
                  y: { type: Type.NUMBER },
                  rotation: { type: Type.NUMBER },
                  style: { type: Type.STRING },
                  size: { type: Type.STRING },
                },
                required: ['text', 'style'],
              },
            },
          },
          required: ['sceneDescription', 'visualPrompt', 'speechBubbles', 'soundEffects'],
        },
      },
    });

    const refined = JSON.parse(response.text?.trim() || '{}');
    res.json({
      success: true,
      panel: {
        ...panel,
        ...refined,
      },
    });
  } catch (error: any) {
    console.error('Error refining panel:', error);
    res.status(500).json({
      success: false,
      error: error?.message || 'Failed to refine panel',
    });
  }
});

// Setup Vite in Dev or Static files in Production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Comic Craft server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
